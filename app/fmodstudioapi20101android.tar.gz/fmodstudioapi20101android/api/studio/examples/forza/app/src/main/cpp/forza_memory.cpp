/*==============================================================================
forza_perf
Copyright (c), Firelight Technologies Pty, Ltd 2012-2018.

This example demonstrates the various ways of playing an event. Controlling event
playback using a persistent instance versus fire and forget.
==============================================================================*/
#include "fmod_studio.hpp"
#include "fmod.hpp"
#include "common.h"
#include <stdarg.h>
#include <vector>

#include "forza_banks.h"
#include "../common/demo_setup.h"

#ifdef _DURANGO
#include "../platforms/xboxone/src/fmod_xboxone.h"
#endif
#include <algorithm>

std::vector<FMOD::Studio::Bank*> gBanks;

class Timer
{
public:
    Timer()
    {
#if defined(__ORBIS__)
        sceKernelClockGettime(SCE_KERNEL_CLOCK_MONOTONIC, &time1);
#elif defined(_DURANGO) || defined(WIN32)
        QueryPerformanceFrequency(&freq);
        QueryPerformanceCounter(&time1);
#endif
    }

    int time()
    {
#if defined(__ORBIS__)
        sceKernelClockGettime(SCE_KERNEL_CLOCK_MONOTONIC, &time2);
        return (time2.tv_sec - time1.tv_sec) * 1000 + (time2.tv_nsec - time1.tv_nsec) / (1000*1000);
#elif defined(_DURANGO) || defined(WIN32)
        QueryPerformanceCounter(&time2);
        return (((time2.QuadPart - time1.QuadPart) * 1000) / freq.QuadPart);
#else
        return 0;
#endif
    }
private:
#if defined(__ORBIS__)
    SceKernelTimespec time1;
    SceKernelTimespec time2;
#elif defined(_DURANGO) || defined(WIN32)
    LARGE_INTEGER freq;
    LARGE_INTEGER time1;
    LARGE_INTEGER time2;
#endif
};

const char* ForzaBankDirectory(const char* bankName)
{
    char bankPath[256];
    sprintf(bankPath, "%s%s", BANK_DIRECTORY, bankName);
    return Common_MediaPath(bankPath);
}

int gLastMemory = 0;
void PrintMemory(bool absolute, const char* format, ...)
{
    int curmem;
    FMOD::Memory_GetStats(&curmem, 0);

    char buffer[256];
    va_list args;
    va_start(args, format);
    vsprintf(buffer, format, args);
    va_end(args);

    int amount = (absolute ? curmem : (curmem - gLastMemory));
    Common_TTY("%s : %.3f kB\n", buffer, amount/1024.0f);
    gLastMemory = curmem;
}

void LoadBankAndPrintMemory(FMOD::Studio::System* system, const char* bankName)
{
    FMOD::Studio::Bank* bank;
    ERRCHECK(system->loadBankFile(ForzaBankDirectory(bankName), FMOD_STUDIO_LOAD_BANK_NORMAL, &bank));
    PrintMemory(false, "Bank Metadata %s", bankName);
    gBanks.push_back(bank);
}

// Load bank samples
void LoadBankSamples(FMOD::Studio::System* system)
{
    Common_TTY("Loading bank samples...\n");
    Timer timer;

    int bankCount = (int)gBanks.size();
    for (int i=0; i<bankCount; ++i)
    {
        ERRCHECK(gBanks[i]->loadSampleData());
    }
    while (1)
    {
        bool anyLoading = false;
        for (int i=0; i<bankCount; ++i)
        {
            FMOD_STUDIO_LOADING_STATE state;
            ERRCHECK(gBanks[i]->getSampleLoadingState(&state));
            if (state == FMOD_STUDIO_LOADING_STATE_LOADING)
            {
                anyLoading = true;
                break;
            }
        }
        if (!anyLoading)
        {
            break;
        }

        ERRCHECK(system->update());
        Common_Sleep(1);
    }

    int time = timer.time();
    Common_TTY("Bank samples took %d ms\n", time);

    PrintMemory(false, "Bank Samples Data");
}

void UnloadBankSamples(FMOD::Studio::System* system)
{
    int bankCount = (int)gBanks.size();
    for (int i=0; i<bankCount; ++i)
    {
        ERRCHECK(gBanks[i]->unloadSampleData());
    }
    ERRCHECK(system->flushCommands());
    PrintMemory(false, "Bank Unload Samples Data");
}

// Load samples in random order
void LoadEventSamples(FMOD::Studio::System* system)
{
    Common_TTY("Loading event samples...\n");
    Timer timer;

    int bankCount = (int)gBanks.size();
    std::vector<FMOD::Studio::EventDescription*> events;
    for (int i=0; i<bankCount; ++i)
    {
        int eventCount;
        ERRCHECK(gBanks[i]->getEventCount(&eventCount));
        int curSize = (int)events.size();
        events.resize(curSize + eventCount);
        ERRCHECK(gBanks[i]->getEventList(&events[curSize], eventCount, NULL));
    }

    // Not sure if defined for all platforms
#if defined(__ORBIS__) || defined(_DURANGO) || defined(WIN32)
    std::random_shuffle( events.begin(), events.end() );
#endif

    int eventCount = (int)events.size();
    for (int i=0; i<eventCount; ++i)
    {
        ERRCHECK(events[i]->loadSampleData());
        if ((i % 10) == 0)
        {
            ERRCHECK(system->update());
            Common_Sleep(1);
        }
    }
    while (1)
    {
        bool anyLoading = false;
        for (int i=0; i<eventCount; ++i)
        {
            FMOD_STUDIO_LOADING_STATE state;
            ERRCHECK(events[i]->getSampleLoadingState(&state));
            if (state == FMOD_STUDIO_LOADING_STATE_LOADING)
            {
                anyLoading = true;
                break;
            }
        }
        if (!anyLoading)
        {
            break;
        }

        ERRCHECK(system->update());
        Common_Sleep(1);
    }

    int time = timer.time();
    Common_TTY("Event samples took %d ms\n", time);

    PrintMemory(false, "Event Samples Data");
}
int FMOD_Main()
{
    void *extraDriverData = 0;
    Common_Init( &extraDriverData);
    
    //FMOD::Debug_Initialize(FMOD_DEBUG_LEVEL_WARNING);

    FMOD::Studio::System* system;
    ERRCHECK( FMOD::Studio::System::create(&system) );

    FMOD::System* lowLevelSystem;
    ERRCHECK( system->getCoreSystem(&lowLevelSystem) );

    ERRCHECK( lowLevelSystem->setSoftwareFormat(0, FMOD_SPEAKERMODE_7POINT1, 0) );

    DEMO_Setup(32, system, &extraDriverData);

    ERRCHECK( system->initialize(1, FMOD_STUDIO_INIT_ALLOW_MISSING_PLUGINS, FMOD_INIT_NORMAL, extraDriverData) );

    Common_TTY("Printing memory\n");
    PrintMemory(true, "Start total");
    {
        Timer timer;

        LoadBankAndPrintMemory(system, "MasterBank.bank");
        LoadBankAndPrintMemory(system, "Music_T01_Menu.bank");
        LoadBankAndPrintMemory(system, "Music_T02_Menu.bank");
        LoadBankAndPrintMemory(system, "VO_UI_EN.bank");
        LoadBankAndPrintMemory(system, "Shared_Collisions.bank");
        LoadBankAndPrintMemory(system, "Shared_Tires.bank");
        LoadBankAndPrintMemory(system, "Shared_Tracks.bank");
        LoadBankAndPrintMemory(system, "Shared_UI.bank");
        LoadBankAndPrintMemory(system, "NUL_Car_00.bank");

        int time = timer.time();
        Common_TTY("Loaded all metadata took %d ms\n", time);
        PrintMemory(true, "Metadata total");
    }
    LoadBankSamples(system);
    UnloadBankSamples(system);
    PrintMemory(true, "End total");
    long long sampleRead, bankRead;
    ERRCHECK(lowLevelSystem->getFileUsage(&sampleRead, 0, &bankRead));
    Common_TTY("Bank data read = %llu\n", bankRead);
    Common_TTY("Sample data read = %llu\n", sampleRead);

    ERRCHECK( system->unloadAll() );
    ERRCHECK( system->update() );

    ERRCHECK( system->release() );

    Common_Close();

    return 0;
}
