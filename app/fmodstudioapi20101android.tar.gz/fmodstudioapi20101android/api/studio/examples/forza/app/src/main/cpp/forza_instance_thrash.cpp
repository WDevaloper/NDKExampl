/*==============================================================================
Instance thrash test
Copyright (c), Firelight Technologies Pty, Ltd 2012-2018.

==============================================================================*/
#include "fmod_studio.hpp"
#include "fmod.hpp"
#include "common.h"

#include "../common/demo_setup.h"
#include "forza_banks.h"

static const char* BANK_FILES[] = 
{
    "MasterBank.bank",
    "Music_T01_Menu.bank",
    "Music_T02_Menu.bank",
    "VO_UI_EN.bank",
    "Shared_Collisions.bank",
    "Shared_Tires.bank",
    "Shared_Tracks.bank",
    "Shared_UI.bank",
    "NUL_Car_00.bank",
};
static const int MAX_INSTANCE_LIMIT = 75;
static const int NEW_INSTANCES_PER_FRAME = 20;

int FMOD_Main()
{
    void *extraDriverData = 0;
    Common_Init( &extraDriverData);
    
    FMOD::Debug_Initialize(FMOD_DEBUG_LEVEL_WARNING);

    FMOD::Studio::System* system;
    ERRCHECK( FMOD::Studio::System::create(&system) );

    FMOD::System* lowLevelSystem;
    ERRCHECK( system->getCoreSystem(&lowLevelSystem) );

    ERRCHECK( lowLevelSystem->setSoftwareFormat(0, FMOD_SPEAKERMODE_7POINT1, 0) );

    DEMO_Setup(64, system, &extraDriverData);

    ERRCHECK( system->initialize(1024, FMOD_STUDIO_INIT_ALLOW_MISSING_PLUGINS, FMOD_INIT_NORMAL, extraDriverData) );

    for (int b=0; b<sizeof(BANK_FILES)/sizeof(BANK_FILES[b]); ++b)
    {
        FMOD::Studio::Bank* bank;
        ERRCHECK(system->loadBankFile(Common_MediaPath(BANK_FILES[b]), FMOD_STUDIO_LOAD_BANK_NORMAL, &bank));
    }

    std::vector<FMOD::Studio::EventDescription*> descriptions;
    DEMO_GetAllEventDescriptions(system, &descriptions);

    std::vector<FMOD::Studio::EventInstance*> instances;
    instances.resize(MAX_INSTANCE_LIMIT);

    int index = 0;
    bool keepGoing = true;
    while (keepGoing)
    {
        for (int i=0; i<NEW_INSTANCES_PER_FRAME; ++i)
        {
            int desc = index % descriptions.size();
            int inst = index % instances.size();

            if (instances[inst])
            {
                ERRCHECK(instances[inst]->stop(FMOD_STUDIO_STOP_IMMEDIATE));
                ERRCHECK(instances[inst]->release());
                instances[inst] = NULL;
            }
            ERRCHECK(descriptions[desc]->createInstance(&instances[inst]));
            ERRCHECK(instances[inst]->start());

            index++;
        }

        ERRCHECK(system->update());
        Common_Sleep(20);
        Common_Update();

        DEMO_DrawTitle("InstanceThrash");
        Common_Draw("Created event %d / %d", index % descriptions.size(), descriptions.size());
        Common_Draw("");
        DEMO_DrawStats(system);

        if (Common_BtnPress(BTN_QUIT))
        {
            keepGoing = false;
        }
    }
    ERRCHECK(system->release());

    Common_Close();
    return 0;
}
