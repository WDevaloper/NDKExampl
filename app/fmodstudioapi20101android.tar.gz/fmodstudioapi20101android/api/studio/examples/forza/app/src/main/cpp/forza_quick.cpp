/*==============================================================================
forza_perf
Copyright (c), Firelight Technologies Pty, Ltd 2012-2018.

This example demonstrates the various ways of playing an event. Controlling event
playback using a persistent instance versus fire and forget.
==============================================================================*/
#include "fmod_studio.hpp"
#include "fmod.hpp"
#include "common.h"

#include "forza_banks.h"

#ifdef _DURANGO
#include "../platforms/xboxone/src/fmod_xboxone.h"
#endif
#ifdef __ORBIS__
#include "../platforms/ps4/src/fmod_ps4.h"
#endif

#ifdef _DURANGO
#include "../platforms/xboxone/src/fmod_xboxone.h"
#endif

// Loads the proper forza plugins:
//#define LOAD_FORZA_PLUGINS

// Issues an async flush after loading each bank (async branch only):
#define BANK_FLUSH_COMMANDS

#define INIT_COMMAND_SIZE 16*1024

//#define NOSOUND_71

// Set PROFILE init flag:
#if !defined(NDEBUG)
#define ENABLE_PROFILE
#endif

// Set FMOD_INIT_VOL0_BECOMES_VIRTUAL init flag
#define ENABLE_VOL0VIRTUAL

// Enables studio async flag (async branch only):
//#define DISABLE_ASYNC

// Enables low level thread safety (async branch only):
//#define DISABLE_THREADSAFETY

// Outputs sound as the following wav file:
//#define WRITE_WAV
#ifdef WRITE_WAV
    #ifdef _DURANGO
        static const char* WAV_FILE = "D:\\forza_quick.wav";
    #else
        static const char* WAV_FILE = "forza_quick.wav";
    #endif
#endif

// Issues ORBIS capture start/stop commands automatically part way through test:
//#define ORBIS_PERF_TESTING

// Track allocations
//#define TRACK_ALLOCATIONS

// Loop at end
//#define WAIT_AT_END

// Thrash sample data loading at end
//#define MEDIA_THRASH_TEST

// Capture file to use:
static const char* CAPTURE_FILE_NAME = "forza_quick.cmd.txt";

// Max number of channels to init FMOD with:
static const int MAX_CHANNELS = 512;
static const int MAX_CODECS = 128;

#ifdef TRACK_ALLOCATIONS
#include <map>
#include <mutex>
#include <string>
#include <algorithm>
struct AllocInfo
{
    unsigned int size;
    FMOD_MEMORY_TYPE type;
    std::string sourcestr;
};
std::map<void*, AllocInfo> gAllocs;
std::map<std::string, int> gLocations;
int gMemoryCategory[32];
int gMemoryNone;
int gMemoryTotal;
std::mutex gMutex;
void * F_CALLBACK TestAlloc(unsigned int size, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
    gMutex.lock();
    AllocInfo info = { size, type, sourcestr };
    void* ptr = malloc(size);
    gMemoryTotal += size;
    bool any = false;
    for (int c=0; c<32; ++c)
    {
        if (type & (1<<c))
        {
            gMemoryCategory[c] += size;
            any = true;
        }
    }
    if (!any) gMemoryNone += size;
    gAllocs[ptr] = info;
    gLocations[gAllocs[ptr].sourcestr] += size;
    gMutex.unlock();
    return ptr;
}
void   F_CALLBACK TestFree(void *ptr, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
    gMutex.lock();
    int size = gAllocs[ptr].size;
    gMemoryTotal -= size;
    bool any = false;
    for (int c=0; c<32; ++c)
    {
        if (type & (1<<c))
        {
            gMemoryCategory[c] -= size;
            any = true;
        }
    }
    if (!any) gMemoryNone -= size;
    gLocations[gAllocs[ptr].sourcestr] -= size;
    gAllocs.erase(ptr);
    free(ptr);
    gMutex.unlock();
}
void * F_CALLBACK TestRealloc(void *ptr, unsigned int size, FMOD_MEMORY_TYPE type, const char *sourcestr)
{
    void* newptr = TestAlloc(size, type, sourcestr);
    gMutex.lock();
    int oldsize = gAllocs[ptr].size;
    memcpy(newptr, ptr, size < oldsize ? size : oldsize);
    gMemoryTotal -= oldsize;
    bool any = false;
    for (int c=0; c<32; ++c)
    {
        if (type & (1<<c))
        {
            gMemoryCategory[c] -= oldsize;
            any = true;
        }
    }
    if (!any) gMemoryNone -= oldsize;
    gLocations[gAllocs[ptr].sourcestr] -= oldsize;
    gAllocs.erase(ptr);
    free(ptr);
    gMutex.unlock();
    return newptr;
}
#endif

#if defined(ORBIS_PERF_TESTING)
#include <perf.h>
int g_captureResult;
int g_captureCount = 0;
#endif

#include "demo_parse.h"
#include "demo_play.h"
#include "../common/demo_setup.h"


int FMOD_Main()
{
    void *extraDriverData = 0;
    Common_Init( &extraDriverData);
    
    FMOD::Debug_Initialize(FMOD_DEBUG_LEVEL_WARNING);
#ifdef TRACK_ALLOCATIONS
    FMOD::Memory_Initialize(0, 0, TestAlloc, TestRealloc, TestFree);
#endif

    FMOD::Studio::System* system;
    ERRCHECK( FMOD::Studio::System::create(&system) );

    FMOD::System* lowlevelSystem;
    ERRCHECK( system->getCoreSystem(&lowlevelSystem) );

    FMOD::System* lowLevelSystem = NULL;
    ERRCHECK( system->getCoreSystem(&lowLevelSystem) );
    ERRCHECK( lowLevelSystem->setSoftwareFormat(0, FMOD_SPEAKERMODE_7POINT1, 0) );

    DEMO_Setup(MAX_CODECS, system, &extraDriverData);

#ifdef LOAD_FORZA_PLUGINS
    ERRCHECK( lowlevelSystem->loadPlugin("ShapeEQComp.dll", NULL) );
    ERRCHECK( lowlevelSystem->loadPlugin("iZotopeTrash.dll", NULL) );
    ERRCHECK( lowlevelSystem->loadPlugin("Turn10Saturator.dll", NULL) );
#endif

    FMOD_STUDIO_INITFLAGS studioFlags = FMOD_STUDIO_INIT_ALLOW_MISSING_PLUGINS;
    FMOD_INITFLAGS flags = FMOD_INIT_NORMAL;

#ifdef ENABLE_VOL0VIRTUAL
    flags |= FMOD_INIT_VOL0_BECOMES_VIRTUAL;
#endif
#ifdef ENABLE_PROFILE
    flags |= FMOD_INIT_PROFILE_ENABLE;
#endif
#ifdef DISABLE_ASYNC
    studioFlags |= FMOD_STUDIO_INIT_SYNCHRONOUS_UPDATE;
#endif
#ifdef DISABLE_THREADSAFETY
    flags |= FMOD_INIT_THREAD_UNSAFE;
#endif
#ifdef WRITE_WAV
    lowlevelSystem->setOutput(FMOD_OUTPUTTYPE_WAVWRITER);
    extraDriverData = (void*)WAV_FILE;
#endif

#ifdef NOSOUND_71
    ERRCHECK(lowlevelSystem->setOutput(FMOD_OUTPUTTYPE_NOSOUND));
    ERRCHECK(lowlevelSystem->setSoftwareFormat(48000, FMOD_SPEAKERMODE_7POINT1, 0));
#endif
    ERRCHECK( system->initialize(MAX_CHANNELS, studioFlags, flags, extraDriverData) );

#ifdef LOAD_FORZA_PLUGINS
    ERRCHECK( lowlevelSystem->loadPlugin("ShapeEQComp.dll", NULL) );
    ERRCHECK( lowlevelSystem->loadPlugin("iZotopeTrash.dll", NULL) );
    ERRCHECK( lowlevelSystem->loadPlugin("Turn10Saturator.dll", NULL) );
#endif

#ifdef INBUILT_PLAYBACK
    ERRCHECK(system->playbackCommands(INBUILT_PLAYBACK_FILE));
    ERRCHECK( system->release() );
    Common_Close();
    return 0;
#endif

#ifdef ORBIS_PERF_TESTING
    if (g_captureCount != 0)
    {
        g_captureResult = sceRazorCpuStartCapture();
        printf("Capture = %d\n", g_captureResult);
    }
#endif

    ERRCHECK(DEMO_loadAll(Common_MediaPath(CAPTURE_FILE_NAME)));
    ERRCHECK(DEMO_countdown());
    FMOD_STUDIO_CPU_USAGE cpuAverage;
    ERRCHECK(DEMO_executeAll(system, &cpuAverage));

    printf("Finished\n");

#ifdef COMMAND_SNAPSHOT
    ERRCHECK(system->startRecordCommands(Common_MediaPath("snapshot.cap"), FMOD_STUDIO_RECORD_COMMANDS_NORMAL));
    ERRCHECK(system->stopRecordCommands());
#endif


#ifdef WAIT_AT_END
#ifdef ORBIS_PERF_TESTING
    sceRazorCpuStartCapture();
#endif

    int ticks = 0;
    while (true)
    {
        FMOD_STUDIO_CPU_USAGE cpuStats;
        system->getCPUUsage(&cpuStats);
        Common_Draw("dsp     = %5.2f\n", cpuStats.dspUsage);
        Common_Draw("stream  = %5.2f\n", cpuStats.streamUsage);
        Common_Draw("studio  = %5.2f\n", cpuStats.studioUsage);
        Common_Draw("update  = %5.2f\n", cpuStats.updateUsage);

        long long sampleRead, streamRead, otherRead;
        ERRCHECK(lowLevelSystem->getFileUsage(&sampleRead, &streamRead, &otherRead));
        Common_Draw("bank data   = %llu\n", otherRead);
        Common_Draw("sample data = %llu\n", sampleRead);
        Common_Draw("stream data = %llu\n", streamRead);

        Common_Draw("Waiting at end (%d)", ticks++/100);
        Common_Update();

#ifdef MEDIA_THRASH_TEST
        int cur = ticks % gPlaybackMediaBanks.size();
        int next = (ticks+2) % gPlaybackMediaBanks.size();
        gPlaybackMediaBanks[cur]->loadSampleData();
        gPlaybackMediaBanks[next]->unloadSampleData();
#endif
        Common_Sleep(20);
        ERRCHECK(system->update());
    }
#ifdef ORBIS_PERF_TESTING
    sceRazorCpuStopCapture();
#endif
#endif

    // Print stats for test
    FMOD_STUDIO_CPU_USAGE cpuFinish = {0};
    static const int NUM_CPU_CALLS = 80;
    for (int i=0; i<NUM_CPU_CALLS; ++i)
    {
        FMOD_STUDIO_CPU_USAGE cpuStats;
        system->getCPUUsage(&cpuStats);
        cpuFinish.dspusage += cpuStats.dspusage / NUM_CPU_CALLS;
        cpuFinish.streamusage += cpuStats.streamusage / NUM_CPU_CALLS;
        cpuFinish.geometryusage += cpuStats.dspusage / NUM_CPU_CALLS;
        cpuFinish.updateusage += cpuStats.updateusage / NUM_CPU_CALLS;
        cpuFinish.studiousage += cpuStats.studiousage / NUM_CPU_CALLS;

        Common_Sleep(10);
        ERRCHECK(system->update());
    }

    Common_TTY("Average mix performance\n");
    Common_TTY("Mixer CPU : %.3f %\n", cpuAverage.dspusage);
    Common_TTY("Studio CPU : %.3f %\n", cpuAverage.studiousage);
    Common_TTY("Update CPU : %.3f %\n", cpuAverage.updateusage);

    Common_TTY("Final mix performance\n");
    Common_TTY("Mixer CPU : %.3f %\n", cpuFinish.dspusage);
    Common_TTY("Studio CPU : %.3f %\n", cpuFinish.studiousage);
    Common_TTY("Update CPU : %.3f %\n", cpuFinish.updateusage);

    ERRCHECK( system->unloadAll() );
    ERRCHECK( system->update() );

    ERRCHECK( system->release() );

    Common_Close();

    return 0;
}
