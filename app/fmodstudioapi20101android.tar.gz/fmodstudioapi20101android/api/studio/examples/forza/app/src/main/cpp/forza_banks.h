// Platform-specific banks is now just part of the working directory
const char* BANK_DIRECTORY = "";
