// ----------- Parse code ------------------

// Save memory by pooling strings
#include <set>
#include <string>
std::set<std::string> stringpool;
char* pooled_strdup(const char* input)
{
    std::pair<std::set<std::string>::iterator, bool> ret = stringpool.insert(input);
    return (char*)ret.first->c_str();
}

#define CHECK_RESULT(expr)          { FMOD_RESULT _result = (expr); if (_result != FMOD_OK) { return _result; } }
#define FMOD_ASSERT(x, ret_val)     { if (!(x)) { return ret_val; } }

// Parsing
/*
    This function takes a buffer pointer and returns a pointer to the start of the
    next field, modifying the buffer pointer to point just after the end of the field.
    A single field is a series of characters ending in a newline, comma, end of string.
    It deals with basic scoping of { } brackets and string quoting.
*/
FMOD_RESULT DEMO_ParseField(char **buffer, char** field)
{
    char *cur = *buffer;
    while (*cur == ' ' || *cur == '\t' || *cur == '\n' || *cur == '\r') cur++;
    FMOD_ASSERT(*cur != '\0', FMOD_ERR_FORMAT);

    char *end = cur;
    int numBrackets = 0;
    bool insideQuotedString = false;
    while (true)
    {
        if (*end == ',' && numBrackets == 0 && !insideQuotedString)
        {
            *end = '\0';
            end++;
            break;
        }
        else if (*end == '\n' || *end == '\r')
        {
            FMOD_ASSERT(numBrackets == 0, FMOD_ERR_FORMAT);
            FMOD_ASSERT(!insideQuotedString, FMOD_ERR_FORMAT);
            *end = '\0';
            end++;
            break;
        }
        else if (*end == '\0')
        {
            FMOD_ASSERT(numBrackets == 0, FMOD_ERR_FORMAT);
            FMOD_ASSERT(!insideQuotedString, FMOD_ERR_FORMAT);
            break;
        }
        else if (*end == '\"')
        {
            insideQuotedString = !insideQuotedString;
        }
        else if (!insideQuotedString && *end == '{')
        {
            numBrackets++;
        }
        else if (!insideQuotedString && *end == '}')
        {
            // Stop on mismatched brackets - this can occur when parsing nested fields inside a { } scope
            if (numBrackets == 0)
            {
                break;
            }
            numBrackets--;
        }
        end++;
    }
    *buffer = end;
    *field = cur;
    return FMOD_OK;
}


FMOD_RESULT DEMO_ParseArg(char **buffer, char*& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));
    arg = field;
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, const char*& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));
    arg = field;
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, char* arg, int bufferLength)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));
    FMOD_ASSERT(strlen(field) < bufferLength, FMOD_ERR_FORMAT);
    strcpy(arg, field);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, int& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));

    int ret = sscanf(field, "%d", &arg);
    FMOD_ASSERT(ret == 1, FMOD_ERR_FORMAT);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, unsigned int& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));

    int ret = sscanf(field, "%u", &arg);
    FMOD_ASSERT(ret == 1, FMOD_ERR_FORMAT);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, float& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));

    int ret = sscanf(field, "%f", &arg);
    FMOD_ASSERT(ret == 1, FMOD_ERR_FORMAT);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, bool& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));
    if (0 == strcmp(field, "true"))
    {
        arg = true;
        return FMOD_OK;
    }
    else if (0 == strcmp(field, "false"))
    {
        arg = false;
        return FMOD_OK;
    }
    else
    {
        FMOD_ASSERT(0, FMOD_ERR_FORMAT);
        return FMOD_ERR_FORMAT;
    }
}

FMOD_RESULT DEMO_ParseArg(char **buffer, void*& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));

    int ret = sscanf(field, "%p", &arg);
    FMOD_ASSERT(ret == 1, FMOD_ERR_FORMAT);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, FMOD_VECTOR& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));
    int ret = sscanf(field, "{%f,%f,%f}", &arg.x, &arg.y, &arg.z);
    FMOD_ASSERT(ret == 3, FMOD_ERR_FORMAT);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, FMOD_GUID& arg)
{
    char* field;
    CHECK_RESULT(DEMO_ParseField(buffer, &field));
    unsigned short dataFields[8];

    // Note: In MSVCR seems to ignore the %hh qualifier and thus writes more than the byte* passed in.  So we use temporaries instead.
    int ret = sscanf(field, "{%8x-%4hx-%4hx-%2hx%2hx-%2hx%2hx%2hx%2hx%2hx%2hx}", 
            &arg.Data1, &arg.Data2, &arg.Data3,
            &dataFields[0], &dataFields[1], &dataFields[2], &dataFields[3], &dataFields[4], &dataFields[5], &dataFields[6], &dataFields[7]);
    for (int i=0; i<8; ++i)
    {
        arg.Data4[i] = (unsigned char)dataFields[i];
    }
    FMOD_ASSERT(ret == 11, FMOD_ERR_FORMAT);
    return FMOD_OK;
}


FMOD_RESULT DEMO_ParseArg(char **buffer, FMOD_3D_ATTRIBUTES& arg)
{
    char* curStr;
    CHECK_RESULT(DEMO_ParseField(buffer, &curStr));
    FMOD_ASSERT(*curStr++ == '{', FMOD_ERR_FORMAT);

    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.position));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.velocity));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.forward));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.up));

    FMOD_ASSERT(*curStr++ == '}', FMOD_ERR_FORMAT);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, FMOD_DSP_DESCRIPTION& arg)
{
    char* curStr;
    CHECK_RESULT(DEMO_ParseField(buffer, &curStr));
    FMOD_ASSERT(*curStr++ == '{', FMOD_ERR_FORMAT);

    memset(&arg, 0, sizeof(FMOD_DSP_DESCRIPTION));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.pluginsdkversion));
    
    char* name;
    CHECK_RESULT(DEMO_ParseField(&curStr, &name));
    FMOD_ASSERT(strlen(name) < 32, FMOD_ERR_FORMAT);
    strcpy(arg.name, name);

    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.version));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.numinputbuffers));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.numoutputbuffers));

    FMOD_ASSERT(*curStr++ == '}', FMOD_ERR_FORMAT);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, FMOD_STUDIO_PARAMETER_DESCRIPTION& arg)
{
    char* curStr;
    CHECK_RESULT(DEMO_ParseField(buffer, &curStr));
    FMOD_ASSERT(*curStr++ == '{', FMOD_ERR_FORMAT);

    memset(&arg, 0, sizeof(FMOD_STUDIO_PARAMETER_DESCRIPTION));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.name));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.minimum));
    CHECK_RESULT(DEMO_ParseArg(&curStr, arg.maximum));

    FMOD_ASSERT(*curStr++ == '}', FMOD_ERR_FORMAT);
    return FMOD_OK;
}

FMOD_RESULT DEMO_ParseArg(char **buffer, FMOD_STUDIO_BANK_INFO& arg)
{
    char* curStr;
    CHECK_RESULT(DEMO_ParseField(buffer, &curStr));
    FMOD_ASSERT(*curStr++ == '{', FMOD_ERR_FORMAT);

    // Don't serialise any fields since they can't be replicated in playback anyway
    memset(&arg, 0, sizeof(FMOD_STUDIO_BANK_INFO));

    FMOD_ASSERT(*curStr++ == '}', FMOD_ERR_FORMAT);
    return FMOD_OK;
}

inline FMOD_RESULT DEMO_ParseArgString(char **buffer)
{
    return FMOD_OK;
}
template <class T>
inline FMOD_RESULT DEMO_ParseEnum(char **buffer, T& arg)
{ 
    int temp; 
    FMOD_RESULT r = DEMO_ParseArg(buffer, temp);
    if (r != FMOD_OK)
    {
        return r;
    }
    arg = (T)temp; 
    return FMOD_OK; 
}

template<size_t N>
inline FMOD_RESULT DEMO_ParseArg(char **buffer, char (&arg)[N])                         { return DEMO_ParseArg(buffer, arg, N); }

template <typename Arg1>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2, typename Arg3>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2, Arg3& arg3)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg3));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2, typename Arg3, typename Arg4>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg3));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg4));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg3));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg4));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg5));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, typename Arg6>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg3));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg4));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg5));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg6));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, typename Arg6, typename Arg7>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg6& arg5, Arg5& arg6, Arg7& arg7)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg3));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg4));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg5));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg6));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg7));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, typename Arg6, typename Arg7, typename Arg8>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7, Arg8& arg8)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg3));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg4));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg5));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg6));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg7));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg8));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, typename Arg6, typename Arg7, typename Arg8, typename Arg9>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7, Arg8& arg8, Arg9& arg9)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg3));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg4));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg5));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg6));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg7));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg8));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg9));
    return FMOD_OK;
}

template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5, typename Arg6, typename Arg7, typename Arg8, typename Arg9, typename Arg10>
inline FMOD_RESULT DEMO_ParseArgString(char **buffer, Arg1& arg1, Arg2& arg2, Arg3& arg3, Arg4& arg4, Arg5& arg5, Arg6& arg6, Arg7& arg7, Arg8& arg8, Arg9& arg9, Arg10& arg10)
{
    CHECK_RESULT(DEMO_ParseArg(buffer, arg1));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg2));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg3));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg4));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg5));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg6));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg7));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg8));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg9));
    CHECK_RESULT(DEMO_ParseArg(buffer, arg10));
    return FMOD_OK;
}

// ---------- End Parse code ---------------
