// ----------- Command playback code ------------------
#include <map>
#include <vector>

std::map<int, FMOD::Studio::Bank*> gPlaybackMap_Bank;
std::map<int, FMOD::Studio::EventDescription*> gPlaybackMap_EventDescription;
std::map<int, FMOD::Studio::EventInstance*> gPlaybackMap_EventInstance;
struct ParameterInstanceInfo
{
    FMOD::Studio::EventInstance* eventInstance;
    FMOD_STUDIO_PARAMETER_ID id;
};
std::map<int, ParameterInstanceInfo> gPlaybackMap_ParameterInstance;
std::vector<FMOD::Studio::Bank*> gPlaybackMediaBanks;

struct ExecutionCommand
{
    ExecutionCommand() { }
    virtual ~ExecutionCommand() { }

    virtual const char* getName() { return ""; }

    virtual FMOD_RESULT parse(char* buffer) = 0;
    virtual FMOD_RESULT execute(FMOD::Studio::System* system) = 0;
};

struct CommandTableEntry
{
    typedef FMOD_RESULT CreateAndParseFunction(char* buffer, ExecutionCommand** cmd);
    const char* mName;
    CreateAndParseFunction* mFunction;
};

template <class COMMAND>
FMOD_RESULT createCommand(char* buffer, ExecutionCommand** cmd)
{
    COMMAND* newcmd = new COMMAND();
    ERRCHECK(newcmd->parse(buffer));
    *cmd = newcmd;
    return FMOD_OK;
}

#define COMMAND_NAME(name)  \
    static const char* getStaticName() { return name; } \
    virtual const char* getName() { return name; }

struct ExecutionCommand_system_loadBank : ExecutionCommand
{
    COMMAND_NAME("System::loadBank");

    char filename[256];
    int bankHandle;
    FMOD_RESULT parse(char* buffer) 
    { 
        char temp[256];
        ERRCHECK(DEMO_ParseArgString(&buffer, temp, bankHandle));
        // Fix up filename
        char* lastDir = strrchr(temp, '\\');
        if (lastDir != 0)
        {
            if (BANK_DIRECTORY[1] == ':')
            {
                strcpy(filename, BANK_DIRECTORY);
            }
            else
            {
                strcpy(filename, Common_MediaPath(BANK_DIRECTORY));
            }
            strcat(filename, lastDir+1);
        }
        else
        {
            strcpy(filename, temp);
        }
        return FMOD_OK;
    }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::Bank* bank;

        ERRCHECK(system->loadBankFile(filename, FMOD_STUDIO_LOAD_BANK_NORMAL, &bank));
        printf("Loaded bank: %s\n", filename);

        int eventCount = 0;
        bank->getEventCount(&eventCount);
        if (eventCount > 0)
        {
            gPlaybackMediaBanks.push_back(bank);
        }
        gPlaybackMap_Bank[bankHandle] = bank;
#ifdef BANK_FLUSH_COMMANDS
        ERRCHECK(system->flushCommands());
#endif
        return FMOD_OK;
    }
};
struct ExecutionCommand_bank_loadSampleData : ExecutionCommand
{
    COMMAND_NAME("Bank::loadSampleData");

    int bankHandle;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, bankHandle); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::Bank* bank = gPlaybackMap_Bank[bankHandle];
#ifndef MEDIA_THRASH_TEST
        ERRCHECK(bank->loadSampleData());
#endif
        return FMOD_OK;
    }
};
struct ExecutionCommand_bank_unloadSampleData : ExecutionCommand
{
    COMMAND_NAME("Bank::unloadSampleData");

    int bankHandle;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, bankHandle); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::Bank* bank = gPlaybackMap_Bank[bankHandle];
        ERRCHECK(bank->unloadSampleData());
        return FMOD_OK;
    }
};
struct ExecutionCommand_bank_unload : ExecutionCommand
{
    COMMAND_NAME("Bank::unload");

    int bankHandle;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, bankHandle); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::Bank* bank = gPlaybackMap_Bank[bankHandle];
        ERRCHECK(bank->unload());
        return FMOD_OK;
    }
};
struct ExecutionCommand_system_lookupEventID : ExecutionCommand
{
    COMMAND_NAME("System::lookupEventID");

    const char* name;
    FMOD_GUID id;
    FMOD_RESULT parse(char* buffer) 
    { 
        ERRCHECK(DEMO_ParseArgString(&buffer, name, id));
        name = pooled_strdup(name);
        return FMOD_OK;
    }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        char temp[1024] = {0};
        sprintf(temp, "event:%s", name);
        FMOD_RESULT result = system->lookupID(temp, &id);
        if (result != FMOD_OK && result != FMOD_ERR_EVENT_NOTFOUND)
        {
            ERRCHECK(result);
        }
        return FMOD_OK;
    }
};
struct ExecutionCommand_system_getEvent : ExecutionCommand
{
    COMMAND_NAME("System::getEvent");

    FMOD_GUID id;
    int  mode; // FMOD_STUDIO_LOADING_MODE
    int eventHandle;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, id, mode, eventHandle); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventDescription* eventDesc;
        ERRCHECK(system->getEventByID(&id, &eventDesc));
        gPlaybackMap_EventDescription[eventHandle] = eventDesc;
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventDescription_createInstance : ExecutionCommand
{
    COMMAND_NAME("EventDescription::createInstance");

    int eventHandle;
    int instanceHandle;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, eventHandle, instanceHandle); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventDescription* eventDesc = gPlaybackMap_EventDescription[eventHandle];
        FMOD::Studio::EventInstance* eventInst;
        ERRCHECK(eventDesc->createInstance(&eventInst));
        gPlaybackMap_EventInstance[instanceHandle] = eventInst;
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventDescription_getMaximumDistance : ExecutionCommand
{
    COMMAND_NAME("EventDescription::getMaximumDistance");

    int eventHandle;
    float distance;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, eventHandle, distance); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventDescription* eventDesc = gPlaybackMap_EventDescription[eventHandle];
        ERRCHECK(eventDesc->getMaximumDistance(&distance));
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventDescription_is3D : ExecutionCommand
{
    COMMAND_NAME("EventDescription::is3D");

    int eventHandle;
    bool is3D;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, eventHandle, is3D); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventDescription* eventInst = gPlaybackMap_EventDescription[eventHandle];
        ERRCHECK(eventInst->is3D(&is3D));
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventInstance_start : ExecutionCommand
{
    COMMAND_NAME("EventInstance::start");

    int instanceHandle;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, instanceHandle); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventInstance* eventInst = gPlaybackMap_EventInstance[instanceHandle];
        ERRCHECK(eventInst->start());
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventInstance_stop : ExecutionCommand
{
    COMMAND_NAME("EventInstance::stop");

    int instanceHandle;
    int mode;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, instanceHandle, mode); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventInstance* eventInst = gPlaybackMap_EventInstance[instanceHandle];
        ERRCHECK(eventInst->stop((FMOD_STUDIO_STOP_MODE)mode));
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventInstance_release : ExecutionCommand
{
    COMMAND_NAME("EventInstance::release");

    int instanceHandle;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, instanceHandle); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventInstance* eventInst = gPlaybackMap_EventInstance[instanceHandle];
        ERRCHECK(eventInst->release());
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventInstance_setVolume : ExecutionCommand
{
    COMMAND_NAME("EventInstance::setVolume");

    int instanceHandle;
    float volume;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, instanceHandle, volume); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventInstance* eventInst = gPlaybackMap_EventInstance[instanceHandle];
        ERRCHECK(eventInst->setVolume(volume));
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventInstance_set3DAttributes : ExecutionCommand
{
    COMMAND_NAME("EventInstance::set3DAttributes");

    int instanceHandle;
    FMOD_3D_ATTRIBUTES attr;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, instanceHandle, attr); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventInstance* eventInst = gPlaybackMap_EventInstance[instanceHandle];
        ERRCHECK(eventInst->set3DAttributes(&attr));
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventInstance_getPlaybackState : ExecutionCommand
{
    COMMAND_NAME("EventInstance::getPlaybackState");

    int instanceHandle;
    int state;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, instanceHandle, state); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventInstance* eventInst = gPlaybackMap_EventInstance[instanceHandle];
        FMOD_STUDIO_PLAYBACK_STATE state2;
        ERRCHECK(eventInst->getPlaybackState(&state2));
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventInstance_getParameter : ExecutionCommand
{
    COMMAND_NAME("EventInstance::getParameter");

    int instanceHandle;
    const char* name;
    int paramHandle;
    FMOD_RESULT parse(char* buffer) 
    { 
        ERRCHECK(DEMO_ParseArgString(&buffer, instanceHandle, name, paramHandle));
        name = pooled_strdup(name);
        return FMOD_OK;
    }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventInstance* eventInst = gPlaybackMap_EventInstance[instanceHandle];
        if (paramHandle != 0)
        {
            FMOD::Studio::EventDescription* eventDesc = nullptr;
            ERRCHECK(eventInst->getDescription(&eventDesc));

            FMOD_STUDIO_PARAMETER_DESCRIPTION paramDesc;
            FMOD_RESULT paramResult;
            paramResult = eventDesc->getParameterDescriptionByName(name, &paramDesc);
            if (paramResult == FMOD_OK)
            {
                ParameterInstanceInfo paramInfo;
                paramInfo.eventInstance = eventInst;
                paramInfo.id = paramDesc.id;
                gPlaybackMap_ParameterInstance[paramHandle] = paramInfo;
            }
        }
        return FMOD_OK;
    }
};
struct ExecutionCommand_eventInstance_setParameterValue : ExecutionCommand
{
    COMMAND_NAME("EventInstance::setParameterValue");

    int instanceHandle;
    const char* name;
    float value;
    FMOD_RESULT parse(char* buffer) 
    { 
        ERRCHECK(DEMO_ParseArgString(&buffer, instanceHandle, name, value));
        name = pooled_strdup(name);
        return FMOD_OK;
    }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        FMOD::Studio::EventInstance* eventInst = gPlaybackMap_EventInstance[instanceHandle];
        eventInst->setParameterByName(name, value);
        return FMOD_OK;
    }
};
struct ExecutionCommand_parameterInstance_setValue : ExecutionCommand
{
    COMMAND_NAME("ParameterInstance::setValue");

    int paramHandle;
    float value;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, paramHandle, value); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        ParameterInstanceInfo paramInfo = gPlaybackMap_ParameterInstance[paramHandle];
        ERRCHECK(paramInfo.eventInstance->setParameterByID(paramInfo.id, value));
        return FMOD_OK;
    }
};
struct ExecutionCommand_system_setListenerAttributes : ExecutionCommand
{
    COMMAND_NAME("System::setListenerAttributes");

    FMOD_3D_ATTRIBUTES attr;
    FMOD_RESULT parse(char* buffer) { return DEMO_ParseArgString(&buffer, attr); }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        ERRCHECK(system->setListenerAttributes(0, &attr));
        return FMOD_OK;
    }
};
struct ExecutionCommand_playback_frame : ExecutionCommand
{
    COMMAND_NAME("Playback::frame");

    FMOD_RESULT parse(char* buffer) { return FMOD_OK; }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
#ifdef ORBIS_PERF_TESTING
        sceRazorCpuSync();
#endif
        Common_Sleep(20);
        return FMOD_OK;
    }
};
struct ExecutionCommand_system_update : ExecutionCommand
{
    COMMAND_NAME("System::update");

    FMOD_RESULT parse(char* buffer) { return FMOD_OK; }
    FMOD_RESULT execute(FMOD::Studio::System* system)
    {
        ERRCHECK(system->update());
#ifdef DUMP_MEMORY
        int curMemory;
        int maxMemory;
        ERRCHECK(FMOD::Memory_GetStats(&curMemory, &maxMemory));
        static int commandIndex = 0;
        FILE* fpMemory = fopen(DUMP_MEMORY_FILE, "a");
        fprintf(fpMemory, "%d, %d, %d\n", commandIndex, curMemory, maxMemory);
        fclose(fpMemory);
        commandIndex++;
#endif
        return FMOD_OK;
    }
};
#define COMMANDENTRY(cmd) { cmd::getStaticName(), createCommand<cmd> }

static const CommandTableEntry gCommandTable[] =
{
    COMMANDENTRY(ExecutionCommand_system_loadBank),
    COMMANDENTRY(ExecutionCommand_system_setListenerAttributes),
    COMMANDENTRY(ExecutionCommand_system_lookupEventID),
    COMMANDENTRY(ExecutionCommand_system_getEvent),
    COMMANDENTRY(ExecutionCommand_bank_loadSampleData),
    COMMANDENTRY(ExecutionCommand_bank_unloadSampleData),
    COMMANDENTRY(ExecutionCommand_bank_unload),
    COMMANDENTRY(ExecutionCommand_eventDescription_createInstance),
    COMMANDENTRY(ExecutionCommand_eventDescription_getMaximumDistance),
    COMMANDENTRY(ExecutionCommand_eventDescription_is3D),
    COMMANDENTRY(ExecutionCommand_eventInstance_start),
    COMMANDENTRY(ExecutionCommand_eventInstance_stop),
    COMMANDENTRY(ExecutionCommand_eventInstance_release),
    COMMANDENTRY(ExecutionCommand_eventInstance_setVolume),
    COMMANDENTRY(ExecutionCommand_eventInstance_set3DAttributes),
    COMMANDENTRY(ExecutionCommand_eventInstance_getPlaybackState),
    COMMANDENTRY(ExecutionCommand_eventInstance_getParameter),
    COMMANDENTRY(ExecutionCommand_eventInstance_setParameterValue),
    COMMANDENTRY(ExecutionCommand_parameterInstance_setValue),
    COMMANDENTRY(ExecutionCommand_playback_frame)
};

std::vector<ExecutionCommand*> gCommands;
FMOD_RESULT DEMO_Parse(char* buffer)
{
    while (buffer[0] == ' ')
    {
        buffer++;
    }
    if (buffer[0] == '#' || buffer[0] == '\n' || buffer[0] == '\r')
    {
        return FMOD_OK;
    }
    char* nameField;
    DEMO_ParseField(&buffer, &nameField);
    for (int i=0; i<sizeof(gCommandTable)/sizeof(gCommandTable[0]); ++i)
    {
        if (0 == strcmp(gCommandTable[i].mName, nameField))
        {
            ExecutionCommand* cmd;
            ERRCHECK(gCommandTable[i].mFunction(buffer, &cmd));

            gCommands.push_back(cmd);
            if (0 == strcmp("Playback::frame", nameField))
            {
                ExecutionCommand* cmd2;
                ERRCHECK(createCommand<ExecutionCommand_system_update>(buffer, &cmd2));
                gCommands.push_back(cmd2);
            }
            return FMOD_OK;
        }
    }
    printf("Failed to find: %s\n", nameField);
    return FMOD_OK;
}

// ----------- End command playback code ------------------

void DEMO_Print(const char* formatString, ...)
{
    char buffer[512];
    va_list args;
    va_start(args, formatString);
    Common_vsnprintf(buffer, 512, formatString, args);
    va_end(args);
    buffer[512-1] = '\0';
    printf("%s", buffer);
#if defined(WIN32) || defined(_DURANGO)
    OutputDebugStringA(buffer);
#endif
    Common_Draw(buffer);
}


FMOD_RESULT DEMO_loadAll(const char* filename)
{
    DEMO_Print("Loading %s\n", filename);

    FILE* playbackFile = fopen(filename, "rt");
    if (!playbackFile)
    {
        printf("Failed to load '%s'\n", filename);
        ERRCHECK(FMOD_ERR_FILE_NOTFOUND);
    }

    char buffer[1024];
    while (fgets(buffer, 1024, playbackFile) != NULL)
    {
        ERRCHECK(DEMO_Parse(buffer));
    }
    fclose(playbackFile);
    return FMOD_OK;
}
FMOD_RESULT DEMO_countdown()
{
    {
        Common_Update();
    }
    Common_Sleep(1000);
    {
        DEMO_Print("Playing back in 2...\n");
        Common_Update();
    }
    Common_Sleep(1000);
    {
        DEMO_Print("Playing back in 1...\n");
        Common_Update();
    }
    Common_Sleep(1000);
    {
        DEMO_Print("GO!!!\n");
        Common_Update();
    }
    return FMOD_OK;
}

FMOD_RESULT DEMO_executeAll(FMOD::Studio::System* system, FMOD_STUDIO_CPU_USAGE* averageCPU)
{
#if defined(COMMAND_EXECUTION_MEMORY)
        FILE* fp = fopen(COMMAND_EXECUTION_FILE, "w");
        int curMemory1;
        int maxMemory1;
        int curMemory2;
        int maxMemory2;
        ERRCHECK(FMOD::Memory_GetStats(&curMemory1, &maxMemory1));
#endif
    int numCPUSamples = 0;
    memset(averageCPU, 0, sizeof(FMOD_STUDIO_CPU_USAGE));

    for (int i=0; i<gCommands.size(); ++i)
    {
        FMOD_STUDIO_CPU_USAGE cpuStats;
        system->getCPUUsage(&cpuStats);
        averageCPU->dspusage += cpuStats.dspusage;
        averageCPU->streamusage += cpuStats.streamusage;
        averageCPU->geometryusage += cpuStats.geometryusage;
        averageCPU->updateusage += cpuStats.updateusage;
        averageCPU->studiousage += cpuStats.studiousage;
        numCPUSamples++;

        if ((i % 5000) == 0)
        {
            Common_Draw("Executing (%d/%d)\n", i, gCommands.size());

            Common_Draw("dsp     = %5.2f\n", cpuStats.dspusage);
            Common_Draw("stream  = %5.2f\n", cpuStats.streamusage);
            Common_Draw("studio  = %5.2f\n", cpuStats.studiousage);
            Common_Draw("update  = %5.2f\n", cpuStats.updateusage);
#if 1
            FMOD_STUDIO_BUFFER_USAGE usage;
            system->getBufferUsage(&usage);

            Common_Draw("Buffer Cur = %d, Peak = %d, Size = %d",
                    usage.studiocommandqueue.currentusage, 
                    usage.studiocommandqueue.peakusage,
                    usage.studiocommandqueue.capacity);
            Common_Draw("Buffer Stalls = %d (%.3fs)", 
                    usage.studiocommandqueue.stallcount,
                    usage.studiocommandqueue.stalltime);

            if (i <= 50000) system->resetBufferUsage();
#endif
            Common_Update();
        }

#if defined(COMMAND_EXECUTION_MEMORY)
        int curMemory1;
        int maxMemory1;
        ERRCHECK(FMOD::Memory_GetStats(&curMemory1, &maxMemory1));
#endif

        ERRCHECK(gCommands[i]->execute(system));

#if defined(COMMAND_EXECUTION_MEMORY)
        Common_Sleep(25);
        ERRCHECK(system->update());
        Common_Sleep(25);

        int curMemory2;
        int maxMemory2;
        ERRCHECK(FMOD::Memory_GetStats(&curMemory2, &maxMemory2));
        fprintf(fp, "%d, %s, %d, %d\n", i, gCommands[i]->getName(), curMemory1, curMemory2);
        if (i >= 2000) break;
#endif
    }

    if (numCPUSamples > 0)
    {
        averageCPU->dspusage /= numCPUSamples;
        averageCPU->streamusage /= numCPUSamples;
        averageCPU->geometryusage /= numCPUSamples;
        averageCPU->updateusage /= numCPUSamples;
        averageCPU->studiousage /= numCPUSamples;
    }

#if defined(COMMAND_EXECUTION_MEMORY)
    fclose(fp);
#endif

    return FMOD_OK;
}


