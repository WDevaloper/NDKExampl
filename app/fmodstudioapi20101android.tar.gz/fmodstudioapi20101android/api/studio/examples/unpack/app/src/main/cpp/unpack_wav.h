#ifndef _UNPACK_WAV_H
#define _UNPACK_RIFF_H

#include "fmod.hpp"

#ifdef _XBOX

// Static linking, just declare it
namespace FMOD 
{
    FMOD_RESULT FMOD_WriteWavHeader(FILE *fp, FMOD_SOUND_FORMAT format, int numChannels, int sampleRate, unsigned int lengthBytes);
}

#else

#define UNPACK_SUPPORT_PRAGMAPACK

#if defined(UNPACK_SUPPORT_PRAGMAPACK)
    #define UNPACK_PACKED
#else 
    #define UNPACK_PACKED __attribute__((packed))
#endif

#ifdef UNPACK_SUPPORT_PRAGMAPACK
    #pragma pack(1)
#endif

#define UNPACK_WAVE_FORMAT_PCM                         1
#define UNPACK_WAVE_FORMAT_EXTENSIBLE                  0xFFFE /* Microsoft */

static const FMOD_GUID UNPACK_KSDATAFORMAT_SUBTYPE_PCM             = { 0x00000001, 0x0000, 0x0010, { 0x80,0x00,0x00,0xaa,0x00,0x38,0x9b,0x71} };
static const FMOD_GUID UNPACK_KSDATAFORMAT_SUBTYPE_IEEE_FLOAT      = { 0x00000003, 0x0000, 0x0010, { 0x80,0x00,0x00,0xaa,0x00,0x38,0x9b,0x71} };

typedef struct
{
    signed char id[4];
    unsigned int size;
} UNPACK_WAVE_CHUNK;

typedef struct
{
    unsigned short    wFormatTag;   /* format type  */
    unsigned short    nChannels;   /* number of channels (i.e. mono, stereo...)  */
    unsigned int      nSamplesPerSec;   /* sample rate  */
    unsigned int      nAvgBytesPerSec;   /* for buffer estimation  */
    unsigned short    nBlockAlign;   /* block size of data  */
    unsigned short    wBitsPerSample;   /* number of bits per sample of mono data */
    unsigned short    cbSize;   /* the count in bytes of the size of extra information (after cbSize) */
} UNPACK_PACKED  UNPACK_WAVE_FORMATEX;

typedef struct
{
    UNPACK_WAVE_FORMATEX   Format;
    union 
    {
        unsigned short wValidBitsPerSample;   /* bits of precision  */
        unsigned short wSamplesPerBlock;   /* valid if wBitsPerSample==0 */
        unsigned short wReserved;   /* If neither applies, set to zero. */
    } UNPACK_PACKED  Samples;
    unsigned int    dwChannelMask;   /* which channels are */
    FMOD_GUID       SubFormat;
} UNPACK_PACKED  UNPACK_WAVE_FORMATEXTENSIBLE;


#ifdef UNPACK_SUPPORT_PRAGMAPACK
    #pragma pack()
#endif

int Unpack_getBitsFromFormat(FMOD_SOUND_FORMAT format)
{
    switch (format)
    {
        case FMOD_SOUND_FORMAT_PCM8     : return 8;
        case FMOD_SOUND_FORMAT_PCM16    : return 16;
        case FMOD_SOUND_FORMAT_PCM24    : return 24;
        case FMOD_SOUND_FORMAT_PCM32    : return 32;
        case FMOD_SOUND_FORMAT_PCMFLOAT : return 32;
        default  : return 0;
    };
}

namespace FMOD 
{

FMOD_RESULT FMOD_WriteWavHeader(FILE *fp, FMOD_SOUND_FORMAT format, int numChannels, int sampleRate, unsigned int lengthBytes)
{
    if (!fp)
    {
        return FMOD_ERR_INVALID_PARAM;
    }

    int bits = Unpack_getBitsFromFormat(format);

    fseek(fp, 0, SEEK_SET);

    {
        UNPACK_WAVE_CHUNK FmtHdr =
        {
            { 'f','m','t',' '}, 
            sizeof(UNPACK_WAVE_FORMATEXTENSIBLE)
        };

        bool extensible = false;
        if (format == FMOD_SOUND_FORMAT_PCMFLOAT || numChannels > 2 || bits > 16)
        {
            extensible = true;
        }

        UNPACK_WAVE_FORMATEXTENSIBLE Fmt;
        memset(&Fmt, 0, sizeof(Fmt));
        Fmt.Format.wFormatTag = extensible ? UNPACK_WAVE_FORMAT_EXTENSIBLE : UNPACK_WAVE_FORMAT_PCM;
        Fmt.Format.nChannels = numChannels;
        Fmt.Format.nSamplesPerSec = sampleRate;
        Fmt.Format.nAvgBytesPerSec = sampleRate * numChannels * bits / 8;
        Fmt.Format.nBlockAlign = numChannels * bits / 8;
        Fmt.Format.wBitsPerSample = bits;

        if (extensible)
        {
            Fmt.Format.cbSize = sizeof(UNPACK_WAVE_FORMATEXTENSIBLE) - sizeof(UNPACK_WAVE_FORMATEX);
            Fmt.Samples.wValidBitsPerSample = bits;
            memcpy(&Fmt.SubFormat, (format == FMOD_SOUND_FORMAT_PCMFLOAT) ? &UNPACK_KSDATAFORMAT_SUBTYPE_IEEE_FLOAT : &UNPACK_KSDATAFORMAT_SUBTYPE_PCM, sizeof(FMOD_GUID));
        }

        UNPACK_WAVE_CHUNK DataChunk = 
        { 
            {'d','a','t','a'},
            lengthBytes
        };

        UNPACK_WAVE_CHUNK WavHeader = 
        { 
            {'R','I','F','F'}, 
            (unsigned int)(sizeof(FmtHdr) + sizeof(Fmt) + sizeof(DataChunk) + lengthBytes),
        };

        (void)fwrite(&WavHeader, sizeof(WavHeader), 1, fp);
        (void)fwrite("WAVE", 4, 1, fp);
        (void)fwrite(&FmtHdr, sizeof(FmtHdr), 1, fp);
        (void)fwrite(&Fmt, sizeof(Fmt), 1, fp);
        (void)fwrite(&DataChunk, sizeof(DataChunk), 1, fp);
    }

    return FMOD_OK;
}

} // end namespace

#endif // _XBOX

#endif // _UNPACK_RIFF_H