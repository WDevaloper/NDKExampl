#ifndef _UNPACK_RIFF_H
#define _UNPACK_RIFF_H

#include "fmod.hpp"

struct UNPACK_CHUNK
{
    unsigned int id;
    unsigned int type;
    unsigned int size;
    long filepos;
};

unsigned int Unpack_readInt(FILE* fp)
{
    unsigned int val = 0;
    fread(&val, sizeof(unsigned int), 1, fp);
    return val;
}

#define UNPACK_MAKEFOURCC(ch0, ch1, ch2, ch3)  \
    ((unsigned int)(char)(ch0) | ((unsigned int)(char)(ch1) << 8) |  \
    ((unsigned int)(char)(ch2) << 16) | ((unsigned int)(char)(ch3) << 24 ))

static const unsigned int UNPACK_CHUNKID_RIFF       = UNPACK_MAKEFOURCC('R','I','F','F');
static const unsigned int UNPACK_CHUNKID_LIST       = UNPACK_MAKEFOURCC('L','I','S','T');
static const unsigned int UNPACK_CHUNKID_SOUNDDATA  = UNPACK_MAKEFOURCC('S','N','D',' ');

UNPACK_CHUNK Unpack_getChunk(FILE* fp)
{
    UNPACK_CHUNK chunk = {};
    chunk.type = Unpack_readInt(fp);
    chunk.size = Unpack_readInt(fp);
    chunk.filepos = ftell(fp);
    if (chunk.type == UNPACK_CHUNKID_RIFF)
    {
        chunk.id = Unpack_readInt(fp);
    }
    else if (chunk.id == UNPACK_CHUNKID_LIST)
    {
        chunk.id = Unpack_readInt(fp);
    }
    else
    {
        // Atomic
        chunk.id = chunk.type;
    }
    return chunk;
}

void Unpack_seekNextChunk(FILE* fp, UNPACK_CHUNK chunk)
{
    int size2 = (chunk.size + 1) & ~1;
    fseek(fp, chunk.filepos + size2, SEEK_SET);
}

#endif // _UNPACK_RIFF_H