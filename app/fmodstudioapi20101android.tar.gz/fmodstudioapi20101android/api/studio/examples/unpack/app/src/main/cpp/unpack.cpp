#include <iostream>
#include <common.h>

#include <fmod.hpp>
#include <fmod_studio.hpp>
#include <fmod_errors.h>
#include "../common/demo_setup.h"

#include "unpack_riff.h"
#include "unpack_wav.h"

// Define some common functionality for BankRepackerWriter

#define BankWriteLog Common_TTY
#define ASSERT_RESULT_RETURN ERRCHECK

void FMOD_snprintf(char *str, int size, const char *format, ...)
{
    if (size > 0)
    {
        va_list arglist;
        va_start(arglist, format);

        // To catch platforms that return -1 and leave the string unchanged on failure
        str[0] = 0;

        // Platform specific call
        vsnprintf(str, size, format, arglist);

        // Not all platforms insert null terminator on truncation
        str[size - 1] = 0;

        va_end(arglist);
    }
}

#include "../../studio/src/BankRepackerWriter.h"

std::vector<std::string> loadBankList()
{
    std::vector<std::string> stringlist;

    FILE* flist = fopen(Common_MediaPath("banklist.txt"), "rt");
    if (flist)
    {
        char line[1024];
        while (fgets(line, 1024, flist))
        {
            int linelen = strlen(line);
            while (linelen > 0 && iswspace(line[linelen-1]))
            {
                linelen--;
            }
            line[linelen] = '\0';
            stringlist.push_back(line);
        }
        fclose(flist);
    }
    return stringlist;
}

int FMOD_Main()
{
    void *extraDriverData = NULL;
    Common_Init(&extraDriverData);

    FMOD::Debug_Initialize(FMOD_DEBUG_LEVEL_WARNING);

    FMOD::System *system = nullptr;

    ERRCHECK(FMOD::System_Create(&system));
    ERRCHECK(system->setOutput(FMOD_OUTPUTTYPE_NOSOUND));
    ERRCHECK(system->init(64, FMOD_INIT_NORMAL, extraDriverData));

    int overallSoundIndex = 0;

    std::vector<std::string> banklist = loadBankList();
    for (int b=0; b<(int)banklist.size(); ++b)
    {
        Common_TTY("Loading bank '%s'\n", banklist[b].c_str());

        std::vector<std::pair<unsigned int, unsigned int> > fsbFilePos;
        FILE* fp = fopen(Common_MediaPath(banklist[b].c_str()), "rb");
        ERRCHECK(fp == NULL ? FMOD_ERR_FILE_NOTFOUND : FMOD_OK);
        UNPACK_CHUNK chunk = Unpack_getChunk(fp);
        while (chunk.size != 0)
        {
            chunk = Unpack_getChunk(fp);
            if (chunk.size)
            {
                Common_TTY("Got chunk (%c%c%c%c, %u)\n", 
                        ((char*)(&chunk.id))[0],
                        ((char*)(&chunk.id))[1],
                        ((char*)(&chunk.id))[2],
                        ((char*)(&chunk.id))[3],
                        chunk.size);

                if (chunk.id == UNPACK_CHUNKID_SOUNDDATA)
                {
                    long pos = ftell(fp);
                    long pos32 = (pos + 31) & ~31;
                    unsigned int size = chunk.size - (pos32 - pos);
                    fsbFilePos.push_back(std::pair<unsigned int, unsigned int>(pos32, size));
                }
            }
            Unpack_seekNextChunk(fp, chunk);
        }
        fclose(fp);

        for (int f=0; f<(int)fsbFilePos.size(); ++f)
        {
            Common_TTY("Extracting FSB #%d at (%d, %d) in bank %s\n", f, fsbFilePos[f].first, fsbFilePos[f].second, banklist[b].c_str());
            ERRCHECK(BankWriteFSBAudio(system, 
                        Common_MediaPath("."),
                        banklist[b].c_str(),
                        Common_MediaPath("."),
                        f,
                        fsbFilePos[f].first,
                        fsbFilePos[f].second,
                        &overallSoundIndex));
        }
    }

    ERRCHECK(system->release());
    Common_Close();

    return 0;
}