/*==============================================================================
tencent_memory
Copyright (c), Firelight Technologies Pty, Ltd 2012-2018.

Tencent memory test
==============================================================================*/
#include "fmod_studio.hpp"
#include "fmod.hpp"
#include "common.h"
#include <stdarg.h>
#include "../common/demo_setup.h"
#include "FMOD_Studio.hpp"
#include "FMOD_Errors.h"
#include <List>
#include <map>

extern bool Common_Private_Test;

using namespace FMOD;
using namespace FMOD::Studio;

//const char*const EVENT_NAME = "event:/VO/English/Welcome";
//const char*const EVENT_NAME = "event:/Impact/Bullet Impact/ImpactDirt_Normal";
const char*const EVENT_NAME = "event:/Music/Music_Title";

typedef std::list<char*> ListStrings;
typedef std::list<FMOD::Studio::Bank*> ListBanks;
ListStrings* g_LoadedBankList = new ListStrings();
ListStrings* g_UnLoadedBankList = new ListStrings();
ListBanks* g_InMemoryBanks = new ListBanks();
// file content is also the buffer of upper two list
char* g_szFileContent = NULL;
int g_iFileLen = 0;
FMOD::Studio::System* pSys = NULL;
FMOD::Studio::EventDescription* g_pDesc = NULL;
FMOD::Studio::EventInstance* g_pInstance = NULL;
int g_iMemDPSBuffer = 0;
int g_iMemStreamFile = 0;
int g_iMemStreamDecode = 0;
int g_iMemSampleData = 0;
int g_iMemPlugin = 0;
int g_iMemPersist = 0;
int g_iMemOther = 0;
int g_iMemNormal = 0;
int g_iAllMem = 0;
std::map<void*, int> g_mapAllMemory;
std::map<int, int> g_mapAllTypeOfMemory;

void _InitConfig() 
{
    FILE* fp = fopen(Common_MediaPath("bank_list.txt"), "rt");
    if (NULL != fp)
    {
        fseek(fp, 0, SEEK_END);
        g_iFileLen = ftell(fp);
        g_szFileContent = new char[g_iFileLen + 1];
        memset(g_szFileContent, 0, g_iFileLen + 1);
        fseek(fp, 0, SEEK_SET);
        fread(g_szFileContent, g_iFileLen, 1, fp);
        fclose(fp);
    }
    if (NULL != g_szFileContent)
    {
        char* pOldString = g_szFileContent;
        for (int i = 0; i < g_iFileLen; ++i)
        {
            if ('\n' == g_szFileContent[i])
            {
                g_szFileContent[i] = 0;
                // insert
                g_UnLoadedBankList->push_back(pOldString);
                pOldString = g_szFileContent + i + 1;
            }
            else if ('\r' == g_szFileContent[i])
            {
                g_szFileContent[i] = 0;
            }
        }
        if (strlen(pOldString) > 0)
        {
            g_UnLoadedBankList->push_back(pOldString);
        }
    }
}

//#pragma region FMOD Callbacks
void * F_CALLBACK MyAllocCallback(  unsigned int size, FMOD_MEMORY_TYPE type,  const char *sourcestr)
{
    g_iAllMem += size;
    g_mapAllTypeOfMemory[type] += size;
    if (type & FMOD_MEMORY_DSP_BUFFER)
    {
        g_iMemDPSBuffer += size;
    }
    if (type & FMOD_MEMORY_STREAM_FILE)
    {
        g_iMemStreamFile += size;
    }
    if (type & FMOD_MEMORY_STREAM_DECODE)
    {
        g_iMemStreamDecode += size;
    }
    if (type & FMOD_MEMORY_PLUGIN)
    {
        g_iMemPlugin += size;
    }
    if (type & FMOD_MEMORY_PERSISTENT)
    {
        g_iMemPersist += size;
    }
    if (type == FMOD_MEMORY_NORMAL)
    {
        g_iMemNormal += size;
    }
    if (type & FMOD_MEMORY_SAMPLEDATA)
    {
        g_iMemSampleData += size;
    }
    void* ptrBuf = ::malloc(size);
    g_mapAllMemory[ptrBuf] = size;
    return ptrBuf;
}
void * F_CALLBACK MyReallocCallback(  void *ptr,  unsigned int size, FMOD_MEMORY_TYPE type,  const char *sourcestr)
{
    g_iAllMem -= g_mapAllMemory[ptr];
    g_iAllMem += size;
    g_mapAllTypeOfMemory[type] += size;
    g_mapAllTypeOfMemory[type] -= g_mapAllMemory[ptr];
    if (type & FMOD_MEMORY_DSP_BUFFER)
    {
        g_iMemDPSBuffer -= g_mapAllMemory[ptr];
        g_iMemDPSBuffer += size;
    }
    if (type & FMOD_MEMORY_STREAM_FILE)
    {
        g_iMemStreamFile -= g_mapAllMemory[ptr];
        g_iMemStreamFile += size;
    }
    if (type & FMOD_MEMORY_STREAM_DECODE)
    {
        g_iMemStreamDecode -= g_mapAllMemory[ptr];
        g_iMemStreamDecode += size;
    }
    if (type & FMOD_MEMORY_PLUGIN)
    {
        g_iMemPlugin -= g_mapAllMemory[ptr];
        g_iMemPlugin += size;
    }
    if (type & FMOD_MEMORY_PERSISTENT)
    {
        g_iMemPersist -= g_mapAllMemory[ptr];
        g_iMemPersist += size;
    }
    if (type == FMOD_MEMORY_NORMAL)
    {
        g_iMemNormal -= g_mapAllMemory[ptr];
        g_iMemNormal += size;
    }
    if (type & FMOD_MEMORY_SAMPLEDATA)
    {
        g_iMemSampleData -= g_mapAllMemory[ptr];
        g_iMemSampleData += size;
    }
    g_mapAllMemory.erase(ptr);
    void* ptrBuf = ::realloc(ptr, size);
    g_mapAllMemory[ptrBuf] = size;
    return ptrBuf;
}
void F_CALLBACK MyFreeCallback(  void *ptr,  FMOD_MEMORY_TYPE type, const char *sourcestr)
{
    g_iAllMem -= g_mapAllMemory[ptr];
    g_mapAllTypeOfMemory[type] -= g_mapAllMemory[ptr];
    if (type & FMOD_MEMORY_DSP_BUFFER)
    {
        g_iMemDPSBuffer -= g_mapAllMemory[ptr];
    }
    if (type & FMOD_MEMORY_STREAM_FILE)
    {
        g_iMemStreamFile -= g_mapAllMemory[ptr];
    }
    if (type & FMOD_MEMORY_STREAM_DECODE)
    {
        g_iMemStreamDecode -= g_mapAllMemory[ptr];
    }
    if (type & FMOD_MEMORY_PLUGIN)
    {
        g_iMemPlugin -= g_mapAllMemory[ptr];
    }
    if (type & FMOD_MEMORY_PERSISTENT)
    {
        g_iMemPersist -= g_mapAllMemory[ptr];
    }
    if (type == FMOD_MEMORY_NORMAL)
    {
        g_iMemNormal -= g_mapAllMemory[ptr];
    }
    if (type & FMOD_MEMORY_SAMPLEDATA)
    {
        g_iMemSampleData -= g_mapAllMemory[ptr];
    }
    g_mapAllMemory.erase(ptr);
    ::free(ptr);
}
//#pragma endregion

int FMOD_Main()
{
    void *extraDriverData = NULL;
    Common_Init(&extraDriverData);

    _InitConfig();

    // Initing
    Memory_Initialize(NULL, 0, MyAllocCallback, MyReallocCallback, MyFreeCallback, FMOD_MEMORY_ALL);
    //Debug_Initialize(FMOD_DEBUG_TYPE_MEMORY|FMOD_DEBUG_TYPE_TRACE|FMOD_DEBUG_TYPE_FILE, FMOD_DEBUG_MODE_FILE, NULL, g_pFMODDebugFile);

    ERRCHECK(FMOD::Studio::System::create(&pSys));
    ERRCHECK(pSys->initialize(100, FMOD_STUDIO_INIT_NORMAL|FMOD_STUDIO_INIT_LIVEUPDATE, FMOD_INIT_NORMAL | FMOD_INIT_PROFILE_ENABLE, NULL));

    int maxBankCount = g_UnLoadedBankList->size();
    bool shouldLoadMetadata = true;

    // Main loop
    while (true)
    {
        ERRCHECK(pSys->update());

        int loadedBankCount = 0;
        ERRCHECK(pSys->getBankCount(&loadedBankCount));

        int mem_current, mem_max;
        ERRCHECK(FMOD::Memory_GetStats(&mem_current, &mem_max, false));

        DEMO_DrawTitle("Tencent Memory");
        Common_Draw("Memory = %.03f mb curr, %.03f mb max", mem_current / (1024.0f * 1024.0f), mem_max / (1024.0f * 1024.0f));
        Common_Draw("Banks loaded = %d / %d", loadedBankCount, maxBankCount);
        Common_Draw("");

        Common_Draw("Press %s to load %s", Common_BtnStr(BTN_ACTION1), g_UnLoadedBankList->empty() ? "(none)" : g_UnLoadedBankList->front());
        Common_Draw("Press %s to unload last bank", Common_BtnStr(BTN_ACTION2));
        Common_Draw("Press %s to play event", Common_BtnStr(BTN_ACTION3));
        Common_Draw("Press %s to stop and release event", Common_BtnStr(BTN_ACTION4));
        Common_Draw("Press %s to toggle sample load (currently %s)", Common_BtnStr(BTN_MORE), shouldLoadMetadata ? "ON" : "OFF");
        Common_Draw("Press %s to quit", Common_BtnStr(BTN_QUIT));
        Common_Update();
        Common_Sleep(20);

        if (Common_BtnPress(BTN_QUIT))
        {
            break;
        }
        else if (Common_BtnPress(BTN_MORE))
        {
            shouldLoadMetadata = !shouldLoadMetadata;
        }
        else if (Common_BtnPress(BTN_ACTION1) || Common_Private_Test)
        {
            if (g_UnLoadedBankList->size() == 0)
            {
                continue;
            }

            // load a bank1
            FMOD::Studio::Bank* pBank = NULL;
            FMOD_RESULT fr = pSys->loadBankFile(Common_MediaPath(g_UnLoadedBankList->front()), FMOD_STUDIO_LOAD_BANK_NORMAL, &pBank);
            if (shouldLoadMetadata)
            {
                pBank->loadSampleData();
            }
            if (FMOD_OK != fr)
            {
                Common_TTY("Error:%s\n", FMOD_ErrorString(fr));
            }
            if (NULL != pBank)
            {
                //pBank->loadSampleData();
                Common_TTY("Bank %s Loaded!\n", g_UnLoadedBankList->front());
                g_LoadedBankList->push_back(g_UnLoadedBankList->front());
                g_InMemoryBanks->push_back(pBank);
                g_UnLoadedBankList->pop_front();
            }
        }
        else if (Common_BtnPress(BTN_ACTION2))
        {
            if (g_InMemoryBanks->size() == 0)
            {
                continue;
            }
            // unload a bank
            g_InMemoryBanks->back()->unload();
            g_UnLoadedBankList->push_front(g_LoadedBankList->back());
            g_InMemoryBanks->pop_back();
            g_LoadedBankList->pop_back();
            Common_TTY("\nBank %s UnLoaded!\n", g_UnLoadedBankList->front());
        }
        else if (Common_BtnPress(BTN_ACTION3))
        {
            if (NULL != g_pInstance)
            {
                continue;
            }
            pSys->getEvent(EVENT_NAME, &g_pDesc);
            if (NULL != g_pDesc)
            {
                g_pDesc->createInstance(&g_pInstance);
                g_pInstance->start();
            }
            else
            {
                Common_TTY("\nRetrieve event %s FAIL!\n", EVENT_NAME);
            }
        }
        else if (Common_BtnPress(BTN_ACTION4))
        {
            if (NULL == g_pInstance)
            {
                continue;
            }
            g_pInstance->stop(FMOD_STUDIO_STOP_IMMEDIATE);
            g_pInstance->release();
            g_pDesc->unloadSampleData();
            g_pInstance = NULL;
            g_pDesc = NULL;
        }
    }
    
    ERRCHECK(pSys->flushCommands());

    int mem_current, mem_max;
    ERRCHECK(FMOD::Memory_GetStats(&mem_current, &mem_max, false));
    Common_TTY("\nFinal Memory = %.03f mb curr, %.03f mb max\n", mem_current / (1024.0f * 1024.0f), mem_max / (1024.0f * 1024.0f));

    // Uninit [6/28/2015 Johnxu]
    Common_TTY("\nExiting.");
    if (NULL != pSys)
    {
        pSys->release();
    }
    g_LoadedBankList->clear();
    g_UnLoadedBankList->clear();
    if (NULL != g_szFileContent)
    {
        delete [] g_szFileContent;
        g_szFileContent = NULL;
    }

    Common_Close();
    return 0;
}

