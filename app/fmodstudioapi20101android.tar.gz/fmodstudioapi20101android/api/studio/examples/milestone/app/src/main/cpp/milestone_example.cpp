/*==============================================================================
Milestone example
==============================================================================*/
#include "fmod_studio.hpp"
#include "fmod.hpp"
#include "fmod_errors.h"
#include "common.h"
#include "../common/demo_setup.h"
#include <time.h>

const int SCREEN_WIDTH = NUM_COLUMNS;
const int SCREEN_HEIGHT = 16;

const int OPPONENT_COUNT = 23;

int currentScreenPosition = -1;
char screenBuffer[(SCREEN_WIDTH + 1) * SCREEN_HEIGHT + 1] = {0};

void initializeScreenBuffer();
void updateScreenPosition(const FMOD_VECTOR& worldPosition);
void CreateBike(const FMOD::Studio::EventDescription* vehicleDescription, const FMOD::Studio::EventDescription* skidDescription, const FMOD_3D_ATTRIBUTES& attributes, FMOD::Studio::EventInstance** bikeInstance, FMOD::Studio::EventInstance** wheel0Instance, FMOD::Studio::EventInstance** wheel1Instance);


int FMOD_Main()
{
    void *extraDriverData = NULL;
    Common_Init(&extraDriverData);

    FMOD::Studio::System* system = NULL;
    FMOD_RESULT result = FMOD::Studio::System::create(&system);
    ERRCHECK(result);

    DEMO_Setup(64, system, &extraDriverData);

    FMOD::System* lowLevelSystem;
    result = system->getCoreSystem(&lowLevelSystem);
    ERRCHECK(result);
    FMOD_ADVANCEDSETTINGS advSettings = {0};
    advSettings.cbSize = sizeof(FMOD_ADVANCEDSETTINGS);
    advSettings.vol0virtualvol = 0.001f;
    result = lowLevelSystem->setAdvancedSettings(&advSettings);
    ERRCHECK(result);

    FMOD::Debug_Initialize(FMOD_DEBUG_LEVEL_WARNING);
    result = system->initialize(512, FMOD_STUDIO_INIT_SYNCHRONOUS_UPDATE, FMOD_INIT_VOL0_BECOMES_VIRTUAL, extraDriverData);
    ERRCHECK(result);

   //Banks
    FMOD::Studio::Bank* masterBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_vorbis\\Master_Bank.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &masterBank) );

    FMOD::Studio::Bank* stringsBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_vorbis\\Master_Bank.bank.strings"), FMOD_STUDIO_LOAD_BANK_NORMAL, &stringsBank) );

    FMOD::Studio::Bank* vehiclesBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_vorbis\\Bike_HondaGP.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &vehiclesBank) );

    FMOD::Studio::Bank* ambienceBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_vorbis\\Ambience.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &ambienceBank) );

    FMOD::Studio::Bank* environmentBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_vorbis\\Environment.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &environmentBank) );

    FMOD::Studio::Bank* vehicleKitBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_vorbis\\VehicleKit.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &vehicleKitBank) );
    
    //Event ID and description
    FMOD_GUID ambienceID= {0};
    ERRCHECK( system->lookupID("event:/Ambience/Ambience", &ambienceID) );
    FMOD::Studio::EventDescription* ambienceDescription= NULL;
    ERRCHECK( system->getEventByID(&ambienceID, &ambienceDescription) );

    FMOD_GUID environmentID= {0};
    ERRCHECK( system->lookupID("event:/Environment/Environment", &environmentID) );
    FMOD::Studio::EventDescription* environmentDescription= NULL;
    ERRCHECK( system->getEventByID(&environmentID, &environmentDescription) );

    FMOD_GUID vehicleID= {0};
    ERRCHECK( system->lookupID("event:/Engine_Honda", &vehicleID) );
    FMOD::Studio::EventDescription* vehicleDescription= NULL;
    ERRCHECK( system->getEventByID(&vehicleID, &vehicleDescription) );

    FMOD_GUID skidID= {0};
    ERRCHECK( system->lookupID("event:/Skid/Skid", &skidID) );
    FMOD::Studio::EventDescription* skidDescription= NULL;
    ERRCHECK( system->getEventByID(&skidID, &skidDescription) );

    FMOD_GUID gearshiftID= {0};
    ERRCHECK( system->lookupID("event:/VehicleKit/Gear", &gearshiftID) );
    FMOD::Studio::EventDescription* gearshiftDescription= NULL;
    ERRCHECK( system->getEventByID(&gearshiftID, &gearshiftDescription) );

    // Position the listener
    FMOD_3D_ATTRIBUTES attributes = { { 0 } };
    attributes.position.y= 1.0f;
    attributes.forward.z = 1.0f;
    attributes.up.y = 1.0f;
    ERRCHECK( system->setListenerAttributes(0, &attributes) );

    //Event instance
    FMOD::Studio::EventInstance* ambienceInstance= NULL;
    ERRCHECK( ambienceDescription->createInstance(&ambienceInstance) );

    for(size_t i= 0; i < 13; ++i)
    {
        FMOD::Studio::EventInstance* environmentInstance= NULL;
        ERRCHECK( environmentDescription->createInstance(&environmentInstance) );
        //10 units in front of the listener
        attributes.position.z += 70.0f;
        ERRCHECK( environmentInstance->set3DAttributes(&attributes) );	
        ERRCHECK( environmentInstance->start() );
    }

    ERRCHECK( ambienceInstance->start() );	

    initializeScreenBuffer();

    FMOD::Studio::EventInstance* bikePlayerInstance[2];
    FMOD::Studio::EventInstance* wheelPlayerInstanceArray[2][2];
    //1 units in front of the listener
    attributes.position.y= 0.5f;
    attributes.position.z = 1.0f;
    CreateBike(vehicleDescription, skidDescription, attributes, &bikePlayerInstance[0], &wheelPlayerInstanceArray[0][0], &wheelPlayerInstanceArray[1][0]);
    CreateBike(vehicleDescription, skidDescription, attributes, &bikePlayerInstance[1], &wheelPlayerInstanceArray[0][1], &wheelPlayerInstanceArray[1][1]);

#if 0
    FMOD::Studio::EventInstance* bikeOpponentInstanceArray[OPPONENT_COUNT];
    FMOD::Studio::EventInstance* wheelOpponentInstanceArray[OPPONENT_COUNT*2];
#endif
    ERRCHECK( bikePlayerInstance[0]->start() );
    ERRCHECK( wheelPlayerInstanceArray[0][0]->start() );
    ERRCHECK( wheelPlayerInstanceArray[1][0]->start() );

    ERRCHECK( bikePlayerInstance[1]->start() );
    ERRCHECK( wheelPlayerInstanceArray[0][1]->start() );
    ERRCHECK( wheelPlayerInstanceArray[1][1]->start() );

    //Player parameters
    FMOD_STUDIO_PARAMETER_DESCRIPTION parameterDescription;

    FMOD_STUDIO_PARAMETER_ID playerLoadID;
    FMOD_STUDIO_PARAMETER_ID playerRpmID;
    FMOD_STUDIO_PARAMETER_ID playerHighlightedID;
    FMOD_STUDIO_PARAMETER_ID wheelSpeedID;
    FMOD_STUDIO_PARAMETER_ID wheelIntensityID;

    ERRCHECK( vehicleDescription->getParameterDescriptionByName("rpm", &parameterDescription) );
    playerRpmID = parameterDescription.id;
    ERRCHECK( vehicleDescription->getParameterDescriptionByName("Load", &parameterDescription) );
    playerLoadID = parameterDescription.id;
    ERRCHECK( vehicleDescription->getParameterDescriptionByName("isHighlighted", &parameterDescription) );
    playerHighlightedID = parameterDescription.id;

    ERRCHECK( skidDescription->getParameterDescriptionByName("Speed", &parameterDescription) );
    wheelSpeedID = parameterDescription.id;
    ERRCHECK( skidDescription->getParameterDescriptionByName("Intensity", &parameterDescription) );
    wheelIntensityID = parameterDescription.id;

    for (int j=0; j<2; ++j)
    {
        bikePlayerInstance[j]->setParameterByID(playerHighlightedID, 1.f);
    }

    //starting grid
    //	   Z
    //	   ^
    //     |
    //     |....
    //     4  ...			Opponent2
    //
    //     3   Opponent1
    //
    //	   2				Opponent0
    //
    //     1    Player
    //
    //	   0   Listener			
    //            0             2	----->X
#if 0

    //Create opponents sound instances and parameters
    FMOD::Studio::ParameterInstance* bikeOpponentRpm[OPPONENT_COUNT];
    FMOD::Studio::ParameterInstance* bikeOpponentLoad[OPPONENT_COUNT];
    FMOD::Studio::ParameterInstance* bikeOpponentWheel0Speed[OPPONENT_COUNT];
    FMOD::Studio::ParameterInstance* bikeOpponentWheel0Intensity[OPPONENT_COUNT];
    FMOD::Studio::ParameterInstance* bikeOpponentWheel1Speed[OPPONENT_COUNT];
    FMOD::Studio::ParameterInstance* bikeOpponentWheel1Intensity[OPPONENT_COUNT];

    FMOD_3D_ATTRIBUTES opponentAttributes = attributes; //start from the player bike position
    for(size_t i= 0; i < OPPONENT_COUNT; ++i)
    {
        opponentAttributes.position.z += 1.0f;
        opponentAttributes.position.x= ( (i%2) == 0 ) ? 2.f : 0.f;

        size_t wheel0index= 2*i;
        size_t wheel1index= 2*i + 1;
        CreateBike(vehicleDescription, skidDescription, opponentAttributes, &bikeOpponentInstanceArray[i], &wheelOpponentInstanceArray[wheel0index], &wheelOpponentInstanceArray[wheel1index]);

        ERRCHECK( bikeOpponentInstanceArray[i]->getParameter("rpm", &bikeOpponentRpm[i]) );
        ERRCHECK( bikeOpponentInstanceArray[i]->getParameter("Load", &bikeOpponentLoad[i]) );
        ERRCHECK( wheelOpponentInstanceArray[wheel0index]->getParameter("Speed", &bikeOpponentWheel0Speed[i]) );
        ERRCHECK( wheelOpponentInstanceArray[wheel0index]->getParameter("Intensity", &bikeOpponentWheel0Intensity[i]) );
        ERRCHECK( wheelOpponentInstanceArray[wheel1index]->getParameter("Speed", &bikeOpponentWheel1Speed[i]) );
        ERRCHECK( wheelOpponentInstanceArray[wheel1index]->getParameter("Intensity", &bikeOpponentWheel1Intensity[i]) );
    }
#endif

    // TODO: Replace with wrappers around FMOD_OS_Time* functions
    //LARGE_INTEGER frequency;			// ticks per second
    //LARGE_INTEGER currentTime, newTime; // ticks
    //
    // get ticks per second
    //QueryPerformanceFrequency(&frequency);
    //float freq= 1.f/frequency.QuadPart*1000.f;
    //
    //QueryPerformanceCounter(&currentTime);

    float randFactor= rand()/float(RAND_MAX);
    float totalTime= 0.f; //in seconds
    float playerRpmFactor= 0.f;
    float playerLoadFactor= 0.f;
    float PI2= asin(1.f)*4.f;
    float randomPhase[OPPONENT_COUNT];
    float factorPeriod[OPPONENT_COUNT];
    for(size_t i= 0; i < OPPONENT_COUNT; ++i)
    {
        randFactor= rand()/float(RAND_MAX);
        randomPhase[i]= 10*randFactor;
        factorPeriod[i]= PI2/(4 + randFactor*6); //rand between 4 and 6
    }

    //reset position
    FMOD_3D_ATTRIBUTES reset= { { 0 } };
    attributes = reset;
    attributes.forward.z = 1.0f;
    attributes.up.y = 1.0f;

    bool autoDrive= true;
    do
    {
        //QueryPerformanceCounter(&newTime);
        //unsigned elapsedMilliseconds= (newTime.QuadPart - currentTime.QuadPart) * freq; //msec
        //QueryPerformanceCounter(&currentTime);
        //
        //totalTime+= (elapsedMilliseconds/1000.f);
        randFactor= rand()/float(RAND_MAX);

        Common_Update();

#if 0
        for(size_t i= 0; i < OPPONENT_COUNT; ++i)
        {
            float opponentFactor= (1.f + sin(randomPhase[i] + totalTime * factorPeriod[i]))/2.f;

            bikeOpponentRpm[i]->setValue(opponentFactor*18000);
            bikeOpponentLoad[i]->setValue(-20.f + opponentFactor* 140.f);
            bikeOpponentWheel0Speed[i]->setValue(opponentFactor);
            bikeOpponentWheel1Speed[i]->setValue(opponentFactor);
            bikeOpponentWheel0Intensity[i]->setValue(opponentFactor);
            bikeOpponentWheel1Intensity[i]->setValue(opponentFactor);
        }
#endif
        if(autoDrive)
        {
            playerRpmFactor= (1.f + sin(totalTime * PI2/4))/2.f; //5 seconds cycle
            playerLoadFactor= (1.f + sin(2 + totalTime * PI2/4))/2.f; //5 seconds cycle and 2 seconds phase offset
        }
        else
        {
             if (Common_BtnDown(BTN_LEFT))
             {
                 playerRpmFactor-= 0.02;
                 playerRpmFactor= (playerRpmFactor< 0.f) ? 0.f : playerRpmFactor;
             }
         
             if (Common_BtnDown(BTN_RIGHT))
             {
                 playerRpmFactor+= 0.02;
                 playerRpmFactor= (playerRpmFactor> 1.f) ? 1.f : playerRpmFactor;
             }
         
             if (Common_BtnDown(BTN_UP))
             {
                 playerLoadFactor+= 0.02;
                 playerLoadFactor= (playerLoadFactor> 1.f) ? 1.f : playerLoadFactor;
                 for (int j=0; j<2; ++j)
                    bikePlayerInstance[j]->setParameterByID(playerLoadID, -20.f + playerLoadFactor*140.f);
             }
         
             if (Common_BtnDown(BTN_DOWN))
             {
                 playerLoadFactor-= 0.02;
                 playerLoadFactor= (playerLoadFactor< 0.f) ? 0.f : playerLoadFactor;
             }
        }
        
        for (int j=0; j<2; ++j)
        {
            bikePlayerInstance[j]->setParameterByID(playerLoadID, -20.f + playerLoadFactor*140.f);
            bikePlayerInstance[j]->setParameterByID(playerRpmID, playerRpmFactor*18000.f);
        }
        
        if (Common_BtnPress(BTN_ACTION1))
        {
            FMOD::Studio::EventInstance* gearUpEventInstance;
            gearshiftDescription->createInstance(&gearUpEventInstance);
            ERRCHECK(gearUpEventInstance->start());
            ERRCHECK(gearUpEventInstance->release());
        }

        if (Common_BtnPress(BTN_ACTION2))
        {
            FMOD::Studio::EventInstance* gearUpEventInstance;
            ERRCHECK(gearshiftDescription->createInstance(&gearUpEventInstance));
            ERRCHECK(gearUpEventInstance->setParameterByName("Set_Updown", 1.f));
            ERRCHECK(gearUpEventInstance->start());
            ERRCHECK(gearUpEventInstance->release());
        }

        if (Common_BtnPress(BTN_ACTION3))
        {
            autoDrive= !autoDrive;
        }
        //attributes.position.y= 1.f;
        //attributes.position.x= 4*sin(totalTime * PI2/4);
        //attributes.position.z = 4*cos(totalTime * PI2/4);
        //ERRCHECK( system->setListenerAttributes(&attributes) );


        result = system->update();
        ERRCHECK(result);
        
        updateScreenPosition(attributes.position);

        Common_Draw("==================================================");
        Common_Draw("Event 3D Example.");
        Common_Draw("Copyright (c) Firelight Technologies 2015-2018.");
        Common_Draw("==================================================");
        Common_Draw(screenBuffer);
        unsigned timeFactor= 0;
        if(randFactor > 0.5f)
            timeFactor= 1;

        unsigned timeSleep= 35 + timeFactor*80;
        Common_Draw("Time to next update %d milliseconds", timeSleep);
        Common_Draw("Autodrive on/off: %d", autoDrive);
        Common_Draw("Use buttons (%s, %s) for gear and %s to switch to auto drive", Common_BtnStr(BTN_ACTION1), Common_BtnStr(BTN_ACTION2), Common_BtnStr(BTN_ACTION3));
        Common_Draw("If not autodrive use the arrow keys (%s rpm increase, %s rpm decrease, %s load increase, %s load decrease) to control the player bike params", 
            Common_BtnStr(BTN_LEFT), Common_BtnStr(BTN_RIGHT), Common_BtnStr(BTN_UP), Common_BtnStr(BTN_DOWN));
        Common_Draw("Press %s to quit", Common_BtnStr(BTN_QUIT));

        Common_Sleep(timeSleep);
        totalTime += (float)timeSleep * 0.001f;
    } while (!Common_BtnPress(BTN_QUIT));

    result = system->release();
    ERRCHECK(result);

    Common_Close();

    return 0;
}

void initializeScreenBuffer()
{
    memset(screenBuffer, ' ', sizeof(screenBuffer));

    int idx = SCREEN_WIDTH;
    for (int i = 0; i < SCREEN_HEIGHT; ++i)
    {
        screenBuffer[idx] = '\n';
        idx += SCREEN_WIDTH + 1;
    }

    screenBuffer[(SCREEN_WIDTH + 1) * SCREEN_HEIGHT] = '\0';
}

int getCharacterIndex(const FMOD_VECTOR& position)
{
    int row = static_cast<int>(-position.z + (SCREEN_HEIGHT / 2));
    int col = static_cast<int>(position.x + (SCREEN_WIDTH / 2));
    
    if (0 < row && row < SCREEN_HEIGHT && 0 < col && col < SCREEN_WIDTH)
    {
        return (row * (SCREEN_WIDTH + 1)) + col;
    }
    
    return -1;
}

void updateScreenPosition(const FMOD_VECTOR& eventPosition)
{
    if (currentScreenPosition != -1)
    {
        screenBuffer[currentScreenPosition] = ' ';
        currentScreenPosition = -1;
    }

    FMOD_VECTOR origin = {0};
    int idx = getCharacterIndex(origin);
    screenBuffer[idx] = '^';
    
    idx = getCharacterIndex(eventPosition);    
    if (idx != -1)
    {
        screenBuffer[idx] = 'o';
        currentScreenPosition = idx;
    }
}

void CreateBike(const FMOD::Studio::EventDescription* vehicleDescription, const FMOD::Studio::EventDescription* skidDescription, const FMOD_3D_ATTRIBUTES& attributes, FMOD::Studio::EventInstance** bikeInstance, FMOD::Studio::EventInstance** wheel0Instance, FMOD::Studio::EventInstance** wheel1Instance)
{
    ERRCHECK( vehicleDescription->createInstance(bikeInstance) );
    ERRCHECK( skidDescription->createInstance(wheel0Instance) );
    ERRCHECK( skidDescription->createInstance(wheel1Instance) );

    FMOD_3D_ATTRIBUTES wheel0attributes= attributes;
    wheel0attributes.position.y= 0.f;
    wheel0attributes.position.z= attributes.position.z - 0.5f;

    FMOD_3D_ATTRIBUTES wheel1attributes= attributes;
    wheel1attributes.position.y= 0.f;
    wheel1attributes.position.z= attributes.position.z + 0.5f;

    ERRCHECK((*bikeInstance)->set3DAttributes(&attributes));
    ERRCHECK((*wheel0Instance)->set3DAttributes(&wheel0attributes));
    ERRCHECK((*wheel1Instance)->set3DAttributes(&wheel1attributes));

    ERRCHECK( (*bikeInstance)->start() );
//	ERRCHECK( wheel0Instance->start() );
//	ERRCHECK( wheel1Instance->start() );
}
