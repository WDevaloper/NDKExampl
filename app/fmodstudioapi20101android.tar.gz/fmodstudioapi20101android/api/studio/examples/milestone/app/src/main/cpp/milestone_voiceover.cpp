/*==============================================================================
Milestone voiceover example
==============================================================================*/
#include "fmod_studio.hpp"
#include "fmod.hpp"
#include "fmod_errors.h"
#include "common.h"
#include <time.h>

const int SCREEN_WIDTH = NUM_COLUMNS;
const int SCREEN_HEIGHT = 16;

int currentScreenPosition = -1;
char screenBuffer[(SCREEN_WIDTH + 1) * SCREEN_HEIGHT + 1] = {0};

void initializeScreenBuffer();
void updateScreenPosition(const FMOD_VECTOR& worldPosition);

void LoadAndBlock(FMOD::Studio::Bank* bank)
{
    ERRCHECK(bank->loadSampleData());
    while (true)
    {
        FMOD_STUDIO_LOADING_STATE state;
        ERRCHECK(bank->getLoadingState(&state));
        if (state == FMOD_STUDIO_LOADING_STATE_LOADED) break;
    }
}

int FMOD_Main()
{
    void *extraDriverData = NULL;
    Common_Init(&extraDriverData);

    FMOD::Studio::System* system = NULL;
    FMOD_RESULT result = FMOD::Studio::System::create(&system);
    ERRCHECK(result);
    
    FMOD::System* lowLevelSystem= NULL;
    system->getCoreSystem(&lowLevelSystem);

    //low level settings
    FMOD_ADVANCEDSETTINGS advancedSettings;
    memset(&advancedSettings, 0, sizeof(advancedSettings));
    advancedSettings.cbSize = sizeof(FMOD_ADVANCEDSETTINGS);
    advancedSettings.vol0virtualvol= 0.f;
    advancedSettings.maxXMACodecs = 128;
    lowLevelSystem->setSoftwareChannels(128);
    lowLevelSystem->setAdvancedSettings(&advancedSettings);
    lowLevelSystem->setStreamBufferSize(256, FMOD_TIMEUNIT_RAWBYTES);

    //studio settings
    FMOD_STUDIO_ADVANCEDSETTINGS studioAdvancedSettings;
    memset(&studioAdvancedSettings, 0, sizeof(FMOD_STUDIO_ADVANCEDSETTINGS));
    studioAdvancedSettings.cbsize = sizeof(FMOD_STUDIO_ADVANCEDSETTINGS);

    studioAdvancedSettings.commandqueuesize= 16 * 4096;
    system->setAdvancedSettings(&studioAdvancedSettings);

    FMOD_STUDIO_INITFLAGS fmodStudioInitFlags= FMOD_STUDIO_INIT_NORMAL;
    FMOD_INITFLAGS		  fmodInitFlags= FMOD_INIT_3D_RIGHTHANDED | FMOD_INIT_VOL0_BECOMES_VIRTUAL | FMOD_INIT_PROFILE_ENABLE;

    FMOD::Debug_Initialize(FMOD_DEBUG_LEVEL_WARNING);
    result = system->initialize(128, fmodStudioInitFlags, fmodInitFlags, extraDriverData);
    ERRCHECK(result);

   //Banks
    FMOD::Studio::Bank* masterBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_voiceover/Master_Bank.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &masterBank) );

    FMOD::Studio::Bank* stringsBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_voiceover/Master_Bank.bank.strings"), FMOD_STUDIO_LOAD_BANK_NORMAL, &stringsBank) );

    FMOD::Studio::Bank* narratorBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_voiceover/narrator_uk.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &narratorBank) );

    FMOD::Studio::Bank* commentatorBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_voiceover/commentator_uk.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &commentatorBank) );

    FMOD::Studio::Bank* menuBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_voiceover/menu.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &menuBank) );

    FMOD::Studio::Bank* musicBank= NULL;
    ERRCHECK( system->loadBankFile(Common_MediaPath("milestone_voiceover/Music.bank"), FMOD_STUDIO_LOAD_BANK_NORMAL, &musicBank) );



    //Event ID and description
    FMOD_GUID musicID= {0};
    ERRCHECK( system->lookupID("event:/Music/music", &musicID) );
    FMOD::Studio::EventDescription* musicDescription= NULL;
    ERRCHECK( system->getEventByID(&musicID, &musicDescription) );

    FMOD_GUID confirmID= {0};
    ERRCHECK( system->lookupID("event:/Menu/SFX/MenuFlash/confirm", &confirmID) );
    FMOD::Studio::EventDescription* confirmDescription= NULL;
    ERRCHECK( system->getEventByID(&confirmID, &confirmDescription) );

    if (false)
    {
        FMOD_GUID voiceoverID= {0};
        ERRCHECK( system->lookupID("event:/Narrator/ukenglish/RICR_01", &voiceoverID) );
        FMOD::Studio::EventDescription* voiceoverDescription= NULL;
        ERRCHECK( system->getEventByID(&voiceoverID, &voiceoverDescription) );
        ERRCHECK(voiceoverDescription->loadSampleData());
    }

    //Event instance
    FMOD::Studio::EventInstance* musicInstance1= NULL;
    FMOD::Studio::EventInstance* musicInstance2= NULL;
    FMOD::Studio::EventInstance* musicInstance3= NULL;
    ERRCHECK( musicDescription->createInstance(&musicInstance1) );
    ERRCHECK( musicDescription->createInstance(&musicInstance2) );
    ERRCHECK( musicDescription->createInstance(&musicInstance3) );
    ERRCHECK( musicInstance1->start() );

    musicInstance2->setParameterByName("Album", 2.f);
    ERRCHECK( musicInstance2->start() );

    initializeScreenBuffer();


    float randFactor= rand()/float(RAND_MAX);
    
    do
    {

        randFactor= rand()/float(RAND_MAX);

        Common_Update();

        if (Common_BtnPress(BTN_ACTION1))
        {
                ERRCHECK( musicInstance3->start() );

                FMOD::Studio::EventInstance* confirmInstance= NULL;
                ERRCHECK( confirmDescription->createInstance(&confirmInstance) );
                ERRCHECK( confirmInstance->start() );

                FMOD_GUID voiceoverID= {0};
                ERRCHECK( system->lookupID("event:/Narrator/ukenglish/RICR_01", &voiceoverID) );
                FMOD::Studio::EventDescription* voiceoverDescription= NULL;
                ERRCHECK( system->getEventByID(&voiceoverID, &voiceoverDescription) );

                ERRCHECK(voiceoverDescription->loadSampleData());
                while (true)
                {
                    result = system->update();
                    ERRCHECK(result);
                    FMOD_STUDIO_LOADING_STATE state;
                    ERRCHECK(voiceoverDescription->getSampleLoadingState(&state));
                    if (state == FMOD_STUDIO_LOADING_STATE_LOADED) break;
                }
                FMOD::Studio::EventInstance* voiceoverInstance= NULL;
                ERRCHECK( voiceoverDescription->createInstance(&voiceoverInstance) );
                ERRCHECK( voiceoverInstance->start() );
        }

/*		if (Common_BtnPress(BTN_ACTION2))
        {
            
        }

        if (Common_BtnPress(BTN_ACTION3))
        {

        }
        */		


        result = system->update();
        ERRCHECK(result);

        Common_Draw("==================================================");
        Common_Draw("Voiceover Example.");
        Common_Draw("Copyright (c) Firelight Technologies 2015-2018.");
        Common_Draw("==================================================");
        Common_Draw(screenBuffer);
        unsigned timeFactor= 0;
        //if(randFactor > 0.5f)
            timeFactor= 0.f;

        unsigned timeSleep= 1 + timeFactor*80;
        Common_Draw("Time to next update %d milliseconds", timeSleep);
        Common_Draw("Press %s to quit", Common_BtnStr(BTN_QUIT));

        Common_Sleep(timeSleep);
    } while (!Common_BtnPress(BTN_QUIT));

    result = system->release();
    ERRCHECK(result);

    Common_Close();

    return 0;
}

void initializeScreenBuffer()
{
    memset(screenBuffer, ' ', sizeof(screenBuffer));

    int idx = SCREEN_WIDTH;
    for (int i = 0; i < SCREEN_HEIGHT; ++i)
    {
        screenBuffer[idx] = '\n';
        idx += SCREEN_WIDTH + 1;
    }

    screenBuffer[(SCREEN_WIDTH + 1) * SCREEN_HEIGHT] = '\0';
}

int getCharacterIndex(const FMOD_VECTOR& position)
{
    int row = static_cast<int>(-position.z + (SCREEN_HEIGHT / 2));
    int col = static_cast<int>(position.x + (SCREEN_WIDTH / 2));
    
    if (0 < row && row < SCREEN_HEIGHT && 0 < col && col < SCREEN_WIDTH)
    {
        return (row * (SCREEN_WIDTH + 1)) + col;
    }
    
    return -1;
}

void updateScreenPosition(const FMOD_VECTOR& eventPosition)
{
    if (currentScreenPosition != -1)
    {
        screenBuffer[currentScreenPosition] = ' ';
        currentScreenPosition = -1;
    }

    FMOD_VECTOR origin = {0};
    int idx = getCharacterIndex(origin);
    screenBuffer[idx] = '^';
    
    idx = getCharacterIndex(eventPosition);    
    if (idx != -1)
    {
        screenBuffer[idx] = 'o';
        currentScreenPosition = idx;
    }
}
