#include <iostream>
#include <map>
#include <common.h>

#include <fmod_studio.hpp>
#include <fmod_errors.h>
#include "../common/demo_setup.h"

const char* REPLAY_CONFIG_FILE = "replay.config";

struct BankMemoryFile
{
    std::string path;
    FMOD::Studio::Bank* bank;
};
bool operator<(const FMOD_GUID &guid1, const FMOD_GUID &guid2)
{
    if (guid1.Data1 != guid2.Data1)
    {
        return guid1.Data1 < guid2.Data1;
    }
    if (guid1.Data2 != guid2.Data2)
    {
        return guid1.Data2 < guid2.Data2;
    }
    if (guid1.Data3 != guid2.Data3)
    {
        return guid1.Data2 < guid2.Data2;
    }
    for (int i = 0; i < 8; ++i)
    {
        if (guid1.Data4[i] != guid2.Data4[i])
        {
            return guid1.Data4[i] < guid2.Data4[i];
        }
    }
    return false;
}
std::map<FMOD_GUID, BankMemoryFile> gBankMap;

FMOD_RESULT F_CALLBACK loadBankCallback(FMOD_STUDIO_COMMANDREPLAY *replay, int commandIndex, const FMOD_GUID *bankGuid, const char *bankFilename, FMOD_STUDIO_LOAD_BANK_FLAGS flags, FMOD_STUDIO_BANK **bank, void *userdata)
{
    auto item = gBankMap.find(*bankGuid);
    if (item == gBankMap.end())
    {
        for (auto i = gBankMap.begin(); i != gBankMap.end(); ++i)
        {
            if (strcmp(i->second.path.c_str(), bankFilename) == 0)
            {
                item = i;
                break;
            }
        }
        if (item == gBankMap.end())
        {
            return FMOD_ERR_FILE_NOTFOUND;
        }
    }
    *bank = (FMOD_STUDIO_BANK*)item->second.bank;
    return FMOD_OK;
}

enum MenuSelectionContext
{
    MenuSelectionContext_Project,
    MenuSelectionContext_Platform,
    MenuSelectionContext_Replay,
    MenuSelectionContext_Exit
};

void updateSelectionIndex(int *index, int size)
{
    if (Common_BtnPress(BTN_UP))
    {
        *index = Common_Max(0, *index - 1);
    }
    else if (Common_BtnPress(BTN_DOWN))
    {
        *index = Common_Min(size - 1, *index + 1);
    }
}

int FMOD_Main()
{
    void *extraDriverData = nullptr;
    Common_Init(&extraDriverData);

    std::vector<DEMO_Project> projects;
    DEMO_LoadReplayConfig(Common_MediaPath(REPLAY_CONFIG_FILE), &projects);

    FMOD::Debug_Initialize(FMOD_DEBUG_LEVEL_WARNING);
    
    MenuSelectionContext context = MenuSelectionContext_Project;
    int selectedProjectIndex = 0;
    int selectedPlatformIndex = 0;
    int selectedReplayIndex = 0;
    bool projectReplay = false;

    DEMO_Replay *selectedReplay;
    do
    {
        Common_Update();

        Common_Draw("==================================================");
        Common_Draw("Replay Player Example.");
        Common_Draw("Copyright (c) Firelight Technologies 2012-2019.");
        Common_Draw("==================================================");
        Common_Draw("");
        MenuSelectionContext currentContext = context;
        switch (context)
        {
            case MenuSelectionContext_Project:
            {
                Common_Draw("Select Project");
                Common_Draw("");
                if (Common_BtnPress(BTN_ACTION1))
                {
                    context = MenuSelectionContext_Platform;
                    selectedPlatformIndex = 0;
                }
                else
                {
                    updateSelectionIndex(&selectedProjectIndex, projects.size());
                }
                for (int i = 0; i < (int)projects.size(); ++i)
                {
                    if (i == selectedProjectIndex)
                    {
                        Common_Draw(" -> %s", projects[i].name.c_str());
                    }
                    else
                    {
                        Common_Draw("    %s", projects[i].name.c_str());
                    }
                }
                break;
            }
            case MenuSelectionContext_Platform:
            {
                Common_Draw("Select Platform");
                Common_Draw("");
                if (Common_BtnPress(BTN_ACTION1))
                {
                    context = MenuSelectionContext_Replay;
                    selectedReplayIndex = 0;
                }
                else if (Common_BtnPress(BTN_ACTION2))
                {
                    context = MenuSelectionContext_Project;
                }
                else
                {
                    updateSelectionIndex(&selectedPlatformIndex, projects[selectedProjectIndex].platforms.size());
                }
                for (int i = 0; i < (int)projects[selectedProjectIndex].platforms.size(); ++i)
                {
                    if (i == selectedPlatformIndex)
                    {
                        Common_Draw(" -> %s", projects[selectedProjectIndex].platforms[i].platformName.c_str());
                    }
                    else
                    {
                        Common_Draw("    %s", projects[selectedProjectIndex].platforms[i].platformName.c_str());
                    }
                }
                break;
            }
            case MenuSelectionContext_Replay:
            {
                Common_Draw("Select Replay");
                Common_Draw("");

                int projectReplayCount = projects[selectedProjectIndex].projectReplays.size();
                int platformReplayCount = projects[selectedProjectIndex].platforms[selectedPlatformIndex].platformReplays.size();
                if (Common_BtnPress(BTN_ACTION1))
                {
                    context = MenuSelectionContext_Exit;
                    if (selectedReplayIndex < projectReplayCount)
                    {
                        projectReplay = true;
                        selectedReplay = &projects[selectedProjectIndex].projectReplays[selectedReplayIndex];
                    }
                    else
                    {
                        selectedReplay = &projects[selectedProjectIndex].platforms[selectedPlatformIndex].platformReplays[selectedReplayIndex - projectReplayCount];
                    }
                }
                else if (Common_BtnPress(BTN_ACTION2))
                {
                    context = MenuSelectionContext_Platform;
                }
                else
                {
                    updateSelectionIndex(&selectedReplayIndex, projectReplayCount + platformReplayCount);
                }
                for (int i = 0; i < projectReplayCount; ++i)
                {
                    if (i == selectedReplayIndex)
                    {
                        Common_Draw(" -> %s", projects[selectedProjectIndex].projectReplays[i].path.c_str());
                    }
                    else
                    {
                        Common_Draw("    %s", projects[selectedProjectIndex].projectReplays[i].path.c_str());
                    }
                }
                if (projectReplayCount > 0)
                {
                    Common_Draw("");
                }
                for (int i = 0; i < platformReplayCount; ++i)
                {
                    if (i == selectedReplayIndex - projectReplayCount)
                    {
                        Common_Draw(" -> %s", projects[selectedProjectIndex].platforms[selectedPlatformIndex].platformReplays[i].path.c_str());
                    }
                    else
                    {
                        Common_Draw("    %s", projects[selectedProjectIndex].platforms[selectedPlatformIndex].platformReplays[i].path.c_str());
                    }
                }
                break;
            }
            case MenuSelectionContext_Exit:
            {
                break;
            }
        }
        
        Common_Draw("");
        Common_Draw("Press %s to move selection up", Common_BtnStr(BTN_UP));
        Common_Draw("Press %s to move selection down", Common_BtnStr(BTN_DOWN));
        Common_Draw("Press %s to confirm selection", Common_BtnStr(BTN_ACTION1));
        if (currentContext != MenuSelectionContext_Project)
        {
            Common_Draw("Press %s to go back", Common_BtnStr(BTN_ACTION2));
        }
        Common_Draw("Press %s to quit", Common_BtnStr(BTN_QUIT));
        Common_Sleep(50);
        if (Common_BtnPress(BTN_QUIT))
        {
            Common_Close();
            return 0;
        }
    } while (context != MenuSelectionContext_Exit);

    FMOD::Studio::System *studioSystem = nullptr;
    ERRCHECK(FMOD::Studio::System::create(&studioSystem));

    DEMO_Setup(selectedReplay->softwareChannelCount, studioSystem, &extraDriverData);

    ERRCHECK(studioSystem->initialize(selectedReplay->maxChannelCount, selectedReplay->studioFlags | FMOD_STUDIO_INIT_ALLOW_MISSING_PLUGINS, selectedReplay->coreFlags, extraDriverData));

    std::string replayPath;
    FMOD::Studio::CommandReplay *playback = nullptr;
    std::string mediaPath = projects[selectedProjectIndex].name;
    mediaPath.append("/");
    if (projectReplay)
    {
        replayPath = mediaPath;
    }
    mediaPath.append(projects[selectedProjectIndex].platforms[selectedPlatformIndex].platformRoot);
    if (!projectReplay)
    {
        replayPath = mediaPath;
        replayPath.append("/");
    }
    replayPath.append(selectedReplay->path);
    DEMO_DrawLoading("Replay", replayPath.c_str(), studioSystem);
    ERRCHECK(studioSystem->loadCommandReplay(Common_MediaPath(replayPath.c_str()), FMOD_STUDIO_COMMANDREPLAY_NORMAL, &playback));

    const char *bankPath = Common_MediaPath(mediaPath.c_str());
    ERRCHECK(playback->setBankPath(bankPath));

    for (unsigned int i = 0; i < projects[selectedProjectIndex].platforms[selectedPlatformIndex].bankFiles.size(); ++i)
    {
        std::string& bankFile = projects[selectedProjectIndex].platforms[selectedPlatformIndex].bankFiles[i];

        char path[1024];
        sprintf(path, "%s/%s", bankPath, bankFile.c_str());
        FMOD::Studio::Bank *bank;
        DEMO_DrawLoading("Replay", bankFile.c_str(), studioSystem);
        FMOD_RESULT result = studioSystem->loadBankFile(path, FMOD_STUDIO_LOAD_BANK_NORMAL, &bank);
        if (result != FMOD_OK)
        {
            continue;
        }
        FMOD_GUID guid;
        bank->getID(&guid);
        BankMemoryFile bankFileEntry;
        bankFileEntry.bank = bank;
        bankFileEntry.path = path;
        gBankMap[guid] = bankFileEntry;
    }
    
    ERRCHECK(playback->setLoadBankCallback(loadBankCallback));

    ERRCHECK(playback->start());

    DEMO_PerfBegin(studioSystem);

    do
    {
        Common_Update();

        if (Common_BtnPress(BTN_MORE))
        {
            gPerfDrawPercentage = !gPerfDrawPercentage;
        }
        if (Common_BtnPress(BTN_ACTION1))
        {
            ERRCHECK(playback->start());
        }

        DEMO_DrawMain("Replay", studioSystem, playback);
        
        ERRCHECK(studioSystem->update());

        Common_Sleep(50);
    } while (!Common_BtnPress(BTN_QUIT));

    ERRCHECK(playback->stop());

    ERRCHECK(studioSystem->update());

    ERRCHECK(studioSystem->release());

    DEMO_PerfEnd();
    Common_Close();

    return 0;
}
